

Open App in VS2026  (install VS2026 Community free version)



Simple Blazor CRUD Builder
 
Generates a QuickGrid (CRUD) from a database instantly.
 
Built with the latest ASP.NET 10.0 and Blazor
 
Identity Login Authority and PassKey ability.
 
Uses Free SQLite database
 
Has all necessary functionality, for a database application (eg CRUD)
Create, Read, Update, Delete.

Export to CSV

Generates all the necessary code (ie Pages, Models, etc), in seconds.
 
Customized easily in Visual Studio 2026 and Visual Studio Code.
 
Click here to Generate Code
 
Contact:- Kalvin Ernst: kalvinlernst@gmail.com




