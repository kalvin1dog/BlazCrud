﻿using appBLL;
using BlazKal.Shared;
using Microsoft.AspNetCore.Mvc;

namespace BlazKal.Server.Controllers
{
    //[Authorize]
    [ApiController]
    //[Route("[controller]")]
    //[Route("[controller]")]
    [Route("api/[controller]")]

    public class TableGenController : ControllerBase
    {
        private IWebHostEnvironment _Env;   //for 3.1 above
        private readonly IConfiguration _iconfiguration;

        public TableGenController(IConfiguration iconfiguration, IWebHostEnvironment envrtmnt)
        {
            _iconfiguration = iconfiguration;
            _Env = envrtmnt;
        }


        //[HttpGet]
        [HttpGet("GetAsyncName")]
        //[Route("api/TableNamesOnly/GetAsyncName")]
        public async Task<IEnumerable<TableName>> GetAsyncName(string Id)
        //public IEnumerable<TableName> GetName()   //works
        {
            string testget = Id;

            List<TableName> ColJobs = new List<TableName>();

            bool returnStatus;
            string returnErrorMessage;

            TableGenBLL ThisBLL = new TableGenBLL();

            //string DBConnectString = _iconfiguration.GetSection("Data").GetSection("ConnectString").Value;
            string DBConnectString = _iconfiguration.GetConnectionString("DefaultConnection");

            ColJobs = ThisBLL.GetTableNamesOnly(
                DBConnectString,
                out returnStatus,
                out returnErrorMessage);

            return ColJobs;

        }



        //[HttpGet]
        [HttpGet("GetAsync")]
        //[Route("api/TableGen/GetAsync")]
        public async Task<IEnumerable<TableGen>> GetAsync(string Id)
        {
            string testget = Id;

            List<TableGen> ColJobs = new List<TableGen>();

            bool returnStatus;
            string returnErrorMessage;

            TableGenBLL ThisBLL = new TableGenBLL();

            //string DBConnectString = _iconfiguration.GetSection("Data").GetSection("ConnectString").Value;
            string DBConnectString = _iconfiguration.GetConnectionString("DefaultConnection");

            ColJobs = ThisBLL.GetTableGens(
                Id,
                DBConnectString,
                out returnStatus,
                out returnErrorMessage);


            return ColJobs;

        }




        //[HttpGet]
        [HttpGet("GetAsyncNameView")]
        //[Route("api/TableNamesOnly/GetAsyncNameView")]
        public async Task<IEnumerable<TableName>> GetAsyncNameView(string Id)
        //public IEnumerable<TableName> GetName()   //works
        {
            string testget = Id;

            List<TableName> ColJobs = new List<TableName>();

            bool returnStatus;
            string returnErrorMessage;

            TableGenBLL ThisBLL = new TableGenBLL();

            //string DBConnectString = _iconfiguration.GetSection("Data").GetSection("ConnectString").Value;
            string DBConnectString = _iconfiguration.GetConnectionString("DefaultConnection");

            ColJobs = ThisBLL.GetTableNamesOnlyView(
                DBConnectString,
                out returnStatus,
                out returnErrorMessage);

            return ColJobs;

        }



        //[HttpGet]
        [HttpGet("GetAsyncView")]
        //[Route("api/TableGen/GetAsyncView")]
        public async Task<IEnumerable<TableGen>> GetAsyncView(string Id)
        {
            string testget = Id;

            List<TableGen> ColJobs = new List<TableGen>();

            bool returnStatus;
            string returnErrorMessage;

            TableGenBLL ThisBLL = new TableGenBLL();

            //string DBConnectString = _iconfiguration.GetSection("Data").GetSection("ConnectString").Value;
            string DBConnectString = _iconfiguration.GetConnectionString("DefaultConnection");

            ColJobs = ThisBLL.GetTableGensView(
                Id,
                DBConnectString,
                out returnStatus,
                out returnErrorMessage);


            return ColJobs;

        }



    }
}
