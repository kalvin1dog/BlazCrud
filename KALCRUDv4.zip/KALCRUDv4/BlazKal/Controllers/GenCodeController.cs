﻿using appBLL;
using BlazKal.Shared;
using Microsoft.AspNetCore.Components.Forms;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore.ValueGeneration.Internal;
using System.Security.Cryptography;

namespace BlazKal.Server.Controllers
{
    //[Authorize]
    [ApiController]
    [Route("api/[controller]")]
    //[Route("[controller]")]
    public class GenCodeController : ControllerBase
    {
        private IWebHostEnvironment _Env;   //for 3.1 above
        private readonly IConfiguration _iconfiguration;
     
        public GenCodeController(IConfiguration iconfiguration, IWebHostEnvironment envrtmnt)
        {
            _iconfiguration = iconfiguration;
            _Env = envrtmnt;
           
        }



        //[HttpPost]
        //[Route("api/GenCode/PostCombo")]
        [HttpPost("PostCombo")]
        public ENTITYTABLE PostCombo([FromBody] ENTITYTABLE paramENTITY)
        {
            //bool returnStatus;
            //string returnErrorMessage;
            //List<string> returnMessage;
            List<string> returnMessage = new List<string>();

            try
            {
                string projstr = "";
                string stradoefcombo = "";
                string progstr = "";
                string tablestr = "";

                //string progstr = "";
                string strpkid = "";
                string column1str = "";
                string column1type = "";
                string column2str = "";
                string column2type = "";
                string column3str = "";
                string column3type = "";
                string column4str = "";
                string column4type = "";
                string column5str = "";
                string column5type = "";

                string column6str = "";
                string column6type = "";
                string column7str = "";
                string column7type = "";
                string column8str = "";
                string column8type = "";
                string column9str = "";
                string column9type = "";
                string column10str = "";
                string column10type = "";
                string column11str = "";
                string column11type = "";

                string childprog2str = "Child";  //another TOPINNERGRID table name
                string childprog1str = "";  //TOPINNERGRID prog name
                string comboprogstr = "";
                string strcomboclicked = "false"; //COMBOGRID flagged(checked) to be used - within TOPGRID Detail page
                string childchildprogstr = "";    //INNERGRID prog name
                string strchild1pkid = "";
                string strchildchild1pkid = "";

                projstr = paramENTITY.projname;
                tablestr = paramENTITY.tablename;
                progstr = paramENTITY.progname;
                //progstr = ThisViewModel.tablename + "7";
                strpkid = paramENTITY.TableColumInPK;

                column1str = paramENTITY.TableColumIn1;
                column1type = paramENTITY.TableColumIn1Type;

                comboprogstr = paramENTITY.TableColumIn;



                column2str = paramENTITY.column2;
                column2type = paramENTITY.column2type;
                column3str = paramENTITY.column3;
                column3type = paramENTITY.column3type;
                column4str = paramENTITY.column4;
                column4type = paramENTITY.column4type;
                column5str = paramENTITY.column5;
                column5type = paramENTITY.column5type;

                column6str = paramENTITY.column6;
                column6type = paramENTITY.column6type;
                column7str = paramENTITY.column7;
                column7type = paramENTITY.column7type;
                column8str = paramENTITY.column8;
                column8type = paramENTITY.column8type;
                column9str = paramENTITY.column9;
                column9type = paramENTITY.column9type;
                column10str = paramENTITY.column10;
                column10type = paramENTITY.column10type;
                column11str = paramENTITY.column11;
                column11type = paramENTITY.column11type;

                //First check for Duplicate program name
                string chk = "";
                //string infile = "appAPP.csproj";
                //var FileName = HttpContext.Server.MapPath(infile);
                //var FileName = Path.Combine(_Env.ContentRootPath, infile);

                if (progstr == null || progstr == "")
                {
                    paramENTITY.ErrChk = false;
                    paramENTITY.ErrMsg = "Program Name Not Found! Please enter.";

                    return paramENTITY;
                }



                string newline = progstr + "Controller.cs";

                string getContFolder = "Controllers/";
                string[] filescontfound = System.IO.Directory.GetFiles(System.IO.Path.Combine(_Env.ContentRootPath, getContFolder), "*.cs", SearchOption.AllDirectories);

                for (int i = 0; i < filescontfound.Length; i++)
                {
                    string ss = filescontfound[i];
                    if (ss.Contains(newline))
                    //if (ss == newline)
                    {
                        chk = "foundDuplicate";  //so found a duplicate
                    }
                }


                //Also check for SQL Reserved Words
                string reswordchk = "";
                string reswordchkmsg = "";
                if (UtilitiesBLL.SQLKeyWordChk(tablestr))   //found in reserved list, so error off
                {
                    reswordchk = "ResWordFound";
                    reswordchkmsg = "Table name is invalid.\nIs a Reserved Word, Please rename it.";
                }
                //END check for SQL Reserved Words




                if (chk == "foundDuplicate")  //so found a duplicate, do not proceed
                {
                    paramENTITY.ErrChk = false;
                    paramENTITY.ErrMsg = "Program Name, is a Duplicate, Please rename it.";

                    return paramENTITY;

                }
                else
                {

                    //Also check for SQL Reserved Words
                    if (reswordchk == "ResWordFound")
                    {
                        paramENTITY.ErrChk = false;
                        paramENTITY.ErrMsg = reswordchkmsg;

                        return paramENTITY;

                    }
                    else
                    {

                        string folderin = _Env.ContentRootPath;

                        string basePath = _Env.ContentRootPath;
                        if (!basePath.EndsWith(System.IO.Path.DirectorySeparatorChar))
                        {
                            basePath += System.IO.Path.DirectorySeparatorChar;
                            folderin = basePath;
                        }

                        /*
                        GenCode.Class1.GenerateCOMBOFIRST(folderin,projstr, progstr, strpkid, column1str, column1type, column2str, column2type,
                            column3str, column3type, column4str, column4type,
                            column5str, column5type, column6str, column6type,
                            column7str, column7type, column8str, column8type,
                            column9str, column9type, column10str, column10type, column11str, column11type,
                            childprog1str, childprog2str, strcomboclicked,
                            comboprogstr, stradoefcombo, tablestr, strchild1pkid, childchildprogstr,
                            strchildchild1pkid);
                        */

                        GenerateCOMBOFIRST(folderin, projstr, progstr, strpkid, column1str, column1type, column2str, column2type,
                            column3str, column3type, column4str, column4type,
                            column5str, column5type, column6str, column6type,
                            column7str, column7type, column8str, column8type,
                            column9str, column9type, column10str, column10type, column11str, column11type,
                            childprog1str, childprog2str, strcomboclicked,
                            comboprogstr, stradoefcombo, tablestr, strchild1pkid, childchildprogstr,
                            strchildchild1pkid);

                        /*
                        GenCode.Class1.GenerateCOMBORSECOND(folderin,projstr, progstr, strpkid, column1str, column1type, column2str, column2type,
                            column3str, column3type, column4str, column4type,
                            column5str, column5type, column6str, column6type,
                            column7str, column7type, column8str, column8type,
                            column9str, column9type, column10str, column10type, column11str, column11type,
                            childprog1str, childprog2str, strcomboclicked, comboprogstr,
                            stradoefcombo, tablestr, strchild1pkid, childchildprogstr,
                            strchildchild1pkid);
                        */

                        GenerateCOMBORSECOND(folderin, projstr, progstr, strpkid, column1str, column1type, column2str, column2type,
                            column3str, column3type, column4str, column4type,
                            column5str, column5type, column6str, column6type,
                            column7str, column7type, column8str, column8type,
                            column9str, column9type, column10str, column10type, column11str, column11type,
                            childprog1str, childprog2str, strcomboclicked, comboprogstr,
                            stradoefcombo, tablestr, strchild1pkid, childchildprogstr,
                            strchildchild1pkid);


                        paramENTITY.ErrChk = true;  //test
                        paramENTITY.ErrMsg = "Code Generated OK.";

                        return paramENTITY;

                    }

                }

            }
            catch (Exception ex)
            {
                paramENTITY.ErrChk = false;
                //paramENTITY.ErrMsg = "Error.";  //test
                paramENTITY.ErrMsg = ex.Message;

                string progstr = paramENTITY.progname;
                //string delresponse = DelProgsAgain(progstr);  //Delete Code again

                return paramENTITY;

            }

        }




        //[HttpPost]
        //[Route("api/GenCode/PostComboAuto")]
        [HttpPost("PostComboAuto")]
        public ENTITYTABLE PostComboAuto([FromBody] ENTITYTABLE paramENTITY)
        {
            //bool returnStatus;
            //string returnErrorMessage;
            //List<string> returnMessage;
            List<string> returnMessage = new List<string>();

            try
            {
                string projstr = "";
                string stradoefcombo = "";
                string progstr = "";
                string tablestr = "";

                //string progstr = "";
                string strpkid = "";
                string column1str = "";
                string column1type = "";
                string column2str = "";
                string column2type = "";
                string column3str = "";
                string column3type = "";
                string column4str = "";
                string column4type = "";
                string column5str = "";
                string column5type = "";

                string column6str = "";
                string column6type = "";
                string column7str = "";
                string column7type = "";
                string column8str = "";
                string column8type = "";
                string column9str = "";
                string column9type = "";
                string column10str = "";
                string column10type = "";
                string column11str = "";
                string column11type = "";

                string childprog2str = "Child";  //another TOPINNERGRID table name
                string childprog1str = "";  //TOPINNERGRID prog name
                string comboprogstr = "";
                string strcomboclicked = "false"; //COMBOGRID flagged(checked) to be used - within TOPGRID Detail page
                string childchildprogstr = "";    //INNERGRID prog name
                string strchild1pkid = "";
                string strchildchild1pkid = "";

                projstr = paramENTITY.projname;
                tablestr = paramENTITY.tablename;
                progstr = paramENTITY.progname;
                //progstr = ThisViewModel.tablename + "7";
                strpkid = paramENTITY.TableColumInPK;

                column1str = paramENTITY.TableColumIn1;
                column1type = paramENTITY.TableColumIn1Type;

                comboprogstr = paramENTITY.TableColumIn;



                column2str = paramENTITY.column2;
                column2type = paramENTITY.column2type;
                column3str = paramENTITY.column3;
                column3type = paramENTITY.column3type;
                column4str = paramENTITY.column4;
                column4type = paramENTITY.column4type;
                column5str = paramENTITY.column5;
                column5type = paramENTITY.column5type;

                column6str = paramENTITY.column6;
                column6type = paramENTITY.column6type;
                column7str = paramENTITY.column7;
                column7type = paramENTITY.column7type;
                column8str = paramENTITY.column8;
                column8type = paramENTITY.column8type;
                column9str = paramENTITY.column9;
                column9type = paramENTITY.column9type;
                column10str = paramENTITY.column10;
                column10type = paramENTITY.column10type;
                column11str = paramENTITY.column11;
                column11type = paramENTITY.column11type;

                //First check for Duplicate program name
                string chk = "";
                //string infile = "appAPP.csproj";
                //var FileName = HttpContext.Server.MapPath(infile);
                //var FileName = Path.Combine(_Env.ContentRootPath, infile);

                if (progstr == null || progstr == "")
                {
                    paramENTITY.ErrChk = false;
                    paramENTITY.ErrMsg = "Program Name Not Found! Please enter.";

                    return paramENTITY;
                }



                string newline = progstr + "Controller.cs";

                string getContFolder = "Controllers/";
                string[] filescontfound = System.IO.Directory.GetFiles(System.IO.Path.Combine(_Env.ContentRootPath, getContFolder), "*.cs", SearchOption.AllDirectories);

                for (int i = 0; i < filescontfound.Length; i++)
                {
                    string ss = filescontfound[i];
                    if (ss.Contains(newline))
                    //if (ss == newline)
                    {
                        chk = "foundDuplicate";  //so found a duplicate
                    }
                }


                //Also check for SQL Reserved Words
                string reswordchk = "";
                string reswordchkmsg = "";
                if (UtilitiesBLL.SQLKeyWordChk(tablestr))   //found in reserved list, so error off
                {
                    reswordchk = "ResWordFound";
                    reswordchkmsg = "Table name is invalid.\nIs a Reserved Word, Please rename it.";
                }
                //END check for SQL Reserved Words




                if (chk == "foundDuplicate")  //so found a duplicate, do not proceed
                {
                    paramENTITY.ErrChk = false;
                    paramENTITY.ErrMsg = "Program Name, is a Duplicate, Please rename it.";

                    return paramENTITY;

                }
                else
                {

                    //Also check for SQL Reserved Words
                    if (reswordchk == "ResWordFound")
                    {
                        paramENTITY.ErrChk = false;
                        paramENTITY.ErrMsg = reswordchkmsg;

                        return paramENTITY;

                    }
                    else
                    {

                        string folderin = _Env.ContentRootPath;

                        string basePath = _Env.ContentRootPath;
                        if (!basePath.EndsWith(System.IO.Path.DirectorySeparatorChar))
                        {
                            basePath += System.IO.Path.DirectorySeparatorChar;
                            folderin = basePath;
                        }

                        /*
                        GenCode.Class1.GenerateCOMBOAUTORFIRST(folderin,projstr, progstr, strpkid, column1str, column1type, column2str, column2type,
                            column3str, column3type, column4str, column4type,
                            column5str, column5type, column6str, column6type,
                            column7str, column7type, column8str, column8type,
                            column9str, column9type, column10str, column10type, column11str, column11type,
                            childprog1str, childprog2str, strcomboclicked,
                            comboprogstr, stradoefcombo, tablestr, strchild1pkid, childchildprogstr,
                            strchildchild1pkid);
                        */

                        GenerateCOMBOAUTORFIRST(folderin, projstr, progstr, strpkid, column1str, column1type, column2str, column2type,
                            column3str, column3type, column4str, column4type,
                            column5str, column5type, column6str, column6type,
                            column7str, column7type, column8str, column8type,
                            column9str, column9type, column10str, column10type, column11str, column11type,
                            childprog1str, childprog2str, strcomboclicked,
                            comboprogstr, stradoefcombo, tablestr, strchild1pkid, childchildprogstr,
                            strchildchild1pkid);


                        /*
                        GenCode.Class1.GenerateCOMBOAUTOSECOND(folderin,projstr, progstr, strpkid, column1str, column1type, column2str, column2type,
                            column3str, column3type, column4str, column4type,
                            column5str, column5type, column6str, column6type,
                            column7str, column7type, column8str, column8type,
                            column9str, column9type, column10str, column10type, column11str, column11type,
                            childprog1str, childprog2str, strcomboclicked, comboprogstr,
                            stradoefcombo, tablestr, strchild1pkid, childchildprogstr,
                            strchildchild1pkid);
                        */

                        GenerateCOMBOAUTOSECOND(folderin, projstr, progstr, strpkid, column1str, column1type, column2str, column2type,
                            column3str, column3type, column4str, column4type,
                            column5str, column5type, column6str, column6type,
                            column7str, column7type, column8str, column8type,
                            column9str, column9type, column10str, column10type, column11str, column11type,
                            childprog1str, childprog2str, strcomboclicked, comboprogstr,
                            stradoefcombo, tablestr, strchild1pkid, childchildprogstr,
                            strchildchild1pkid);


                        paramENTITY.ErrChk = true;  //test
                        paramENTITY.ErrMsg = "Code Generated OK.";

                        return paramENTITY;

                    }

                }

            }
            catch (Exception ex)
            {
                paramENTITY.ErrChk = false;
                //paramENTITY.ErrMsg = "Error.";  //test
                paramENTITY.ErrMsg = ex.Message;

                string progstr = paramENTITY.progname;
                //string delresponse = DelProgsAgain(progstr);  //Delete Code again

                return paramENTITY;

            }

        }



        //[ApiController]
        //[Route("api/GenCode/Post")]
        [HttpPost("Post")]
        public ENTITYTABLE Post([FromBody] ENTITYTABLE paramENTITY)
        {
            //bool returnStatus;
            //string returnErrorMessage;
            //List<string> returnMessage;
            List<string> returnMessage = new List<string>();

            try
            {
                string projstr = "";
                string stradoefcombo = "";
                string progstr = "";
                string tablestr = "";

                //string progstr = "";
                string strpkid = "";
                string column1str = "";
                string column1type = "";
                string column2str = "";
                string column2type = "";
                string column3str = "";
                string column3type = "";
                string column4str = "";
                string column4type = "";
                string column5str = "";
                string column5type = "";

                string column6str = "";
                string column6type = "";
                string column7str = "";
                string column7type = "";
                string column8str = "";
                string column8type = "";
                string column9str = "";
                string column9type = "";
                string column10str = "";
                string column10type = "";
                string column11str = "";
                string column11type = "";

                string childprog2str = "Child";  //another TOPINNERGRID table name
                string childprog1str = "";  //TOPINNERGRID prog name
                string comboprogstr = "";
                string strcomboclicked = "false"; //COMBOGRID flagged(checked) to be used - within TOPGRID Detail page
                string childchildprogstr = "";    //INNERGRID prog name
                string strchild1pkid = "";
                string strchildchild1pkid = "";

                //new for combos
                string strdropcol1In = "";
                string strdropcol2In = "";
                string strdropcol3In = "";
                string strdropcol4In = "";
                string strdropcol5In = "";
                string strdropcol6In = "";
                string strautodropcol1In = "";
                string strautodropcol2In = "";
                string strautodropcol3In = "";
                string strautodropcol4In = "";
                string strautodropcol5In = "";
                string strautodropcol6In = "";

                projstr = paramENTITY.projname;
                tablestr = paramENTITY.tablename;
                progstr = paramENTITY.progname;
                //progstr = ThisViewModel.tablename + "7";
                strpkid = paramENTITY.primarykey;
                column1str = paramENTITY.column1;
                column1type = paramENTITY.column1type;
                column2str = paramENTITY.column2;
                column2type = paramENTITY.column2type;
                column3str = paramENTITY.column3;
                column3type = paramENTITY.column3type;
                column4str = paramENTITY.column4;
                column4type = paramENTITY.column4type;
                column5str = paramENTITY.column5;
                column5type = paramENTITY.column5type;

                column6str = paramENTITY.column6;
                column6type = paramENTITY.column6type;
                column7str = paramENTITY.column7;
                column7type = paramENTITY.column7type;
                column8str = paramENTITY.column8;
                column8type = paramENTITY.column8type;
                column9str = paramENTITY.column9;
                column9type = paramENTITY.column9type;
                column10str = paramENTITY.column10;
                column10type = paramENTITY.column10type;
                column11str = paramENTITY.column11;
                column11type = paramENTITY.column11type;

                //new for combos
                strdropcol1In = paramENTITY.dropcol1In;
                strdropcol2In = paramENTITY.dropcol2In;
                strdropcol3In = paramENTITY.dropcol3In;
                strdropcol4In = paramENTITY.dropcol4In;
                strdropcol5In = paramENTITY.dropcol5In;
                strdropcol6In = paramENTITY.dropcol6In;

                strautodropcol1In = paramENTITY.autodropcol1In;
                strautodropcol2In = paramENTITY.autodropcol2In;
                strautodropcol3In = paramENTITY.autodropcol3In;
                strautodropcol4In = paramENTITY.autodropcol4In;
                strautodropcol5In = paramENTITY.autodropcol5In;
                strautodropcol6In = paramENTITY.autodropcol6In;

                //First check for Duplicate program name
                string chk = "";
                //string infile = "appAPP.csproj";
                //var FileName = HttpContext.Server.MapPath(infile);
                //var FileName = Path.Combine(_Env.ContentRootPath, infile);

                if (progstr == null || progstr == "")
                {
                    paramENTITY.ErrChk = false;
                    paramENTITY.ErrMsg = "Program Name Not Found! Please enter.";

                    return paramENTITY;
                }



                string newline = progstr + "Controller.cs";

                string getContFolder = "Controllers/";
                //string[] filescontfound = System.IO.Directory.GetFiles(System.IO.Path.Combine(_Env.ContentRootPath, getContFolder));
                string[] filescontfound = System.IO.Directory.GetFiles(System.IO.Path.Combine(_Env.ContentRootPath, getContFolder), "*.cs", SearchOption.AllDirectories);
                //string[] filescontfound = System.IO.Directory.GetFiles(System.IO.Path.Combine(_Env.ContentRootPath, getContFolder), "*.cs", SearchOption.AllDirectories);

                for (int i = 0; i < filescontfound.Length; i++)
                {
                    string ss = filescontfound[i];
                    if (ss.Contains(newline))
                    //if (ss == newline)
                    {
                        chk = "foundDuplicate";  //so found a duplicate
                    }
                }


                //Also check for SQL Reserved Words
                string reswordchk = "";
                string reswordchkmsg = "";
                if (UtilitiesBLL.SQLKeyWordChk(tablestr))   //found in reserved list, so error off
                {
                    reswordchk = "ResWordFound";
                    reswordchkmsg = "Table name is invalid.\nIs a Reserved Word, Please rename it.";
                }
                if (UtilitiesBLL.SQLKeyWordChk(column1str))   //found in reserved list, so error off
                {
                    reswordchk = "ResWordFound";
                    reswordchkmsg = "Column 1 name is invalid.\nIs a Reserved Word, Please rename it.";
                }
                if (UtilitiesBLL.SQLKeyWordChk(column2str))   //found in reserved list, so error off
                {
                    reswordchk = "ResWordFound";
                    reswordchkmsg = "Column 2 name is invalid.\nIs a Reserved Word, Please rename it.";
                }
                if (UtilitiesBLL.SQLKeyWordChk(column3str))   //found in reserved list, so error off
                {
                    reswordchk = "ResWordFound";
                    reswordchkmsg = "Column 3 name is invalid.\nIs a Reserved Word, Please rename it.";
                }
                if (UtilitiesBLL.SQLKeyWordChk(column4str))   //found in reserved list, so error off
                {
                    reswordchk = "ResWordFound";
                    reswordchkmsg = "Column 4 name is invalid.\nIs a Reserved Word, Please rename it.";
                }
                //END check for SQL Reserved Words




                if (chk == "foundDuplicate")  //so found a duplicate, do not proceed
                {
                    paramENTITY.ErrChk = false;
                    paramENTITY.ErrMsg = "Program Name, is a Duplicate, Please rename it.";

                    return paramENTITY;

                }
                else
                {

                    //Also check for SQL Reserved Words
                    if (reswordchk == "ResWordFound")
                    {
                        paramENTITY.ErrChk = false;
                        paramENTITY.ErrMsg = reswordchkmsg;

                        return paramENTITY;

                    }
                    else
                    {

                        string folderin = _Env.ContentRootPath;

                        string basePath = _Env.ContentRootPath;
                        if (!basePath.EndsWith(System.IO.Path.DirectorySeparatorChar))
                        {
                            basePath += System.IO.Path.DirectorySeparatorChar;
                            folderin = basePath;
                        }

                        /*
                        GenCode.Class1.GenerateTOPGRIDFIRST(folderin,projstr, progstr, strpkid, column1str, column1type, column2str, column2type,
                            column3str, column3type, column4str, column4type,
                            column5str, column5type, column6str, column6type,
                            column7str, column7type, column8str, column8type,
                            column9str, column9type, column10str, column10type, column11str, column11type,
                            childprog1str, childprog2str, strcomboclicked,
                            comboprogstr, stradoefcombo, tablestr, strchild1pkid, childchildprogstr,
                            strchildchild1pkid, strdropcol1In, strdropcol2In, strdropcol3In, strdropcol4In, strdropcol5In, strdropcol6In,
                            strautodropcol1In, strautodropcol2In, strautodropcol3In, strautodropcol4In, strautodropcol5In, strautodropcol6In);
                        */


                        GenerateTOPGRIDFIRST(folderin, projstr, progstr, strpkid, column1str, column1type, column2str, column2type,
                            column3str, column3type, column4str, column4type,
                            column5str, column5type, column6str, column6type,
                            column7str, column7type, column8str, column8type,
                            column9str, column9type, column10str, column10type, column11str, column11type,
                            childprog1str, childprog2str, strcomboclicked,
                            comboprogstr, stradoefcombo, tablestr, strchild1pkid, childchildprogstr,
                            strchildchild1pkid, strdropcol1In, strdropcol2In, strdropcol3In, strdropcol4In, strdropcol5In, strdropcol6In,
                            strautodropcol1In, strautodropcol2In, strautodropcol3In, strautodropcol4In, strautodropcol5In, strautodropcol6In);


                        /*
                        GenCode.Class1.GenerateTOPGRIDSECOND(folderin,projstr, progstr, strpkid, column1str, column1type, column2str, column2type,
                            column3str, column3type, column4str, column4type,
                            column5str, column5type, column6str, column6type,
                            column7str, column7type, column8str, column8type,
                            column9str, column9type, column10str, column10type, column11str, column11type,
                            childprog1str, childprog2str, strcomboclicked, comboprogstr,
                            stradoefcombo, tablestr, strchild1pkid, childchildprogstr,
                            strchildchild1pkid);
                        */

                        /*
                        GenerateTOPGRIDSECOND(folderin, projstr, progstr, strpkid, column1str, column1type, column2str, column2type,
                            column3str, column3type, column4str, column4type,
                            column5str, column5type, column6str, column6type,
                            column7str, column7type, column8str, column8type,
                            column9str, column9type, column10str, column10type, column11str, column11type,
                            childprog1str, childprog2str, strcomboclicked, comboprogstr,
                            stradoefcombo, tablestr, strchild1pkid, childchildprogstr,
                            strchildchild1pkid);
                        */


                        //Next is for MAUI building code
                        //GenCode.Class1.GenerateTOPGRIDMAUI(folderin, projstr, progstr, strpkid, column1str, column1type, column2str, column2type,
                           // column3str, column3type, column4str, column4type,
                           // column5str, column5type, column6str, column6type,
                           // column7str, column7type, column8str, column8type,
                           // column9str, column9type, column10str, column10type, column11str, column11type,
                           // childprog1str, childprog2str, strcomboclicked,
                           // comboprogstr, stradoefcombo, tablestr, strchild1pkid, childchildprogstr,
                           // strchildchild1pkid, strdropcol1In, strdropcol2In, strdropcol3In, strdropcol4In, strdropcol5In, strdropcol6In,
                           // strautodropcol1In, strautodropcol2In, strautodropcol3In, strautodropcol4In, strautodropcol5In, strautodropcol6In);


                        paramENTITY.ErrChk = true;  //test
                        paramENTITY.ErrMsg = "Code Generated OK.";

                        return paramENTITY;

                    }

                }

            }
            catch (Exception ex)
            {
                paramENTITY.ErrChk = false;
                //paramENTITY.ErrMsg = "Error.";  //test
                paramENTITY.ErrMsg = ex.Message;

                string progstr = paramENTITY.progname;
                string tablestr = paramENTITY.tablename;

                //string delresponse = DelProgsAgain(progstr);  //Delete Code again

                string folderin = "";

                folderin = _Env.ContentRootPath;

                DelALLProgs(progstr, tablestr, folderin);   //Delete code again
                //GenCode.Class1.DelALLProgs(progstr, folderin);   //Delete code again

                return paramENTITY;

            }

        }



        //[HttpPost]
        //[Route("api/DelCode/Post")]
        [HttpPost("PostDel")]
        public ENTITYTABLE PostDel([FromBody] ENTITYTABLE paramENTITY)
        {

            try
            {
                string progstr = "";

                //string tablestr = ThisViewModel.tablename;
                progstr = paramENTITY.progname;

                string modelstr = "";

                modelstr = paramENTITY.tablename;


                //paramENTITY.propnote = "propnote";  //test

                if (progstr == null || progstr == "")
                {
                    List<string> outputMessagesk = new List<string>();

                    //returnStatus = false;
                    //outputMessagesk.Add("Program Name invalid!");

                    paramENTITY.ErrChk = false;
                    paramENTITY.ErrMsg = "Program Name Not Found! Please enter.";

                    return paramENTITY;
                }

                
                string chk = "NotFound";
                string newline = progstr + "Grid.razor";

                string getContFolder = "Components/Pages/" + progstr + "UI/";
                string[] filescontfound = System.IO.Directory.GetFiles(System.IO.Path.Combine(_Env.ContentRootPath, getContFolder));

                for (int i = 0; i < filescontfound.Length; i++)
                {
                    string ss = filescontfound[i];
                    if (ss.Contains(newline))
                    {
                        chk = "foundProg";  //so found already
                    }
                }

                if (chk == "NotFound")
                {
                    paramENTITY.ErrChk = false;
                    paramENTITY.ErrMsg = "Program Name Not Found! Please Change Name.";

                    return paramENTITY;
                }
                


                string folderin = "";

                folderin = _Env.ContentRootPath;

                string basePath = _Env.ContentRootPath;
                if (!basePath.EndsWith(System.IO.Path.DirectorySeparatorChar))
                {
                    basePath += System.IO.Path.DirectorySeparatorChar;
                    folderin = basePath;
                }

                //GenCode.Class1.DelALLProgs(progstr, folderin);
                DelALLProgs(progstr, modelstr, folderin);



                paramENTITY.ErrChk = true;
                paramENTITY.ErrMsg = "Code Deleted OK.";

                return paramENTITY;

            }
            catch (Exception ex)
            {

                paramENTITY.ErrChk = false;
                //paramENTITY.ErrMsg = "Error.";  //test
                paramENTITY.ErrMsg = ex.Message;

                return paramENTITY;
            }

        }


        private static void DecryptAll(string folderin)
        {
            //bool result;
            try
            {

                string outputDecrptcs = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/progBLL.cz");
                string inputDecrpt = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/progBLL.ce");

                Decrypt(inputDecrpt, outputDecrptcs);

                outputDecrptcs = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/progGrid.rzzr");
                inputDecrpt = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/progGrid.cerzzr");

                Decrypt(inputDecrpt, outputDecrptcs);

                outputDecrptcs = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/progGridM.rzzr");
                inputDecrpt = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/progGridM.cerzzr");

                Decrypt(inputDecrpt, outputDecrptcs);


                outputDecrptcs = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/progController.cz");
                inputDecrpt = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/progController.ce");

                Decrypt(inputDecrpt, outputDecrptcs);


                outputDecrptcs = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/projMod.cz");
                inputDecrpt = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/projMod.ce");

                Decrypt(inputDecrpt, outputDecrptcs);


                outputDecrptcs = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/projModM.cz");
                inputDecrpt = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/projModM.ce");

                Decrypt(inputDecrpt, outputDecrptcs);

                outputDecrptcs = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/progViewModel.cz");
                inputDecrpt = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/progViewModel.ce");

                Decrypt(inputDecrpt, outputDecrptcs);


                outputDecrptcs = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/progDialog.rzzr");
                inputDecrpt = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/progDialog.cerzzr");

                Decrypt(inputDecrpt, outputDecrptcs);


                outputDecrptcs = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/progDialogM.rzzr");
                inputDecrpt = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/progDialogM.cerzzr");

                Decrypt(inputDecrpt, outputDecrptcs);

                outputDecrptcs = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/colViewModel.cz");
                inputDecrpt = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/colViewModel.ce");

                Decrypt(inputDecrpt, outputDecrptcs);

                outputDecrptcs = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/colMod.cz");
                inputDecrpt = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/colMod.ce");

                Decrypt(inputDecrpt, outputDecrptcs);

                outputDecrptcs = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/colModM.cz");
                inputDecrpt = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/colModM.ce");

                Decrypt(inputDecrpt, outputDecrptcs);

                outputDecrptcs = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/colController.cz");
                inputDecrpt = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/colController.ce");

                Decrypt(inputDecrpt, outputDecrptcs);


                outputDecrptcs = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/colCombo.rzzr");
                inputDecrpt = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/colCombo.cerzzr");

                Decrypt(inputDecrpt, outputDecrptcs);


                outputDecrptcs = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/colComboM.rzzr");
                inputDecrpt = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/colComboM.cerzzr");

                Decrypt(inputDecrpt, outputDecrptcs);


                outputDecrptcs = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/colBLL.cz");
                inputDecrpt = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/colBLL.ce");

                Decrypt(inputDecrpt, outputDecrptcs);

                //################333

                outputDecrptcs = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/colautoViewModel.cz");
                inputDecrpt = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/colautoViewModel.ce");

                Decrypt(inputDecrpt, outputDecrptcs);

                outputDecrptcs = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/colautoMod.cz");
                inputDecrpt = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/colautoMod.ce");

                Decrypt(inputDecrpt, outputDecrptcs);

                outputDecrptcs = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/colautoModM.cz");
                inputDecrpt = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/colautoModM.ce");

                Decrypt(inputDecrpt, outputDecrptcs);

                outputDecrptcs = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/colautoController.cz");
                inputDecrpt = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/colautoController.ce");

                Decrypt(inputDecrpt, outputDecrptcs);


                outputDecrptcs = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/colautoCombo.rzzr");
                inputDecrpt = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/colautoCombo.cerzzr");

                Decrypt(inputDecrpt, outputDecrptcs);


                outputDecrptcs = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/colautoComboM.rzzr");
                inputDecrpt = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/colautoComboM.cerzzr");

                Decrypt(inputDecrpt, outputDecrptcs);


                outputDecrptcs = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/colautoBLL.cz");
                inputDecrpt = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/colautoBLL.ce");

                Decrypt(inputDecrpt, outputDecrptcs);

                //END Decrypt gen files here
                //----------------------------------------------------------------------------------



                //result = true;
            }
            catch (Exception ex)
            {

                //result = false;
            }
            //return result;
        }




        private static void Decrypt(string inputFilePath, string outputfilePath)
        {
            string EncryptionKey = "MAKV2SPBNI99212";
            using (Aes encryptor = Aes.Create())
            {
                Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(EncryptionKey, new byte[] { 0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76 });
                encryptor.Key = pdb.GetBytes(32);
                encryptor.IV = pdb.GetBytes(16);
                using (FileStream fsInput = new FileStream(inputFilePath, FileMode.Open))
                {
                    using (CryptoStream cs = new CryptoStream(fsInput, encryptor.CreateDecryptor(), CryptoStreamMode.Read))
                    {
                        using (FileStream fsOutput = new FileStream(outputfilePath, FileMode.Create))
                        {
                            int data;
                            while ((data = cs.ReadByte()) != -1)
                            {
                                fsOutput.WriteByte((byte)data);
                            }
                        }
                    }
                }
            }
        }



        private static void Encrypt(string inputFilePath, string outputfilePath)
        {
            string EncryptionKey = "MAKV2SPBNI99212";
            using (Aes encryptor = Aes.Create())
            {
                Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(EncryptionKey, new byte[] { 0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76 });
                encryptor.Key = pdb.GetBytes(32);
                encryptor.IV = pdb.GetBytes(16);
                using (FileStream fsOutput = new FileStream(outputfilePath, FileMode.Create))
                {
                    using (CryptoStream cs = new CryptoStream(fsOutput, encryptor.CreateEncryptor(), CryptoStreamMode.Write))
                    {
                        using (FileStream fsInput = new FileStream(inputFilePath, FileMode.Open))
                        {
                            int data;
                            while ((data = fsInput.ReadByte()) != -1)
                            {
                                cs.WriteByte((byte)data);
                            }
                        }
                    }
                }
            }
        }







        //[HttpPost]
        //[Route("api/EncryptCode/Post")]
        [HttpPost("PostEncrypt")]
        public ENTITYTABLE PostEncrypt([FromBody] ENTITYTABLE paramENTITY)
        {

            try
            {
                string folderin = _Env.ContentRootPath;
                //bool resultk = GenCode.Class1.EncryptFilesTOPGRID(folderin);
                bool resultk = EncryptFilesTOPGRID(folderin);

                if (!resultk)
                {
                    paramENTITY.ErrChk = false;
                    paramENTITY.ErrMsg = "Code Encrypted ERROR!";
                }
                else
                {

                    paramENTITY.ErrChk = true;
                    paramENTITY.ErrMsg = "Code Encrypted OK.";

                }


                return paramENTITY;

            }
            catch (Exception ex)
            {

                paramENTITY.ErrChk = false;
                //paramENTITY.ErrMsg = "Error.";  //test
                paramENTITY.ErrMsg = ex.Message;

                return paramENTITY;
            }

        }

        //---------------------------------------------------------------------------------------------------------------------------
        //===========================================================================================================================
        //
        //

        private static void u00A0(string A_0, string A_1)
        {
            string password = "MAKV2SPBNI99212";
            using (Aes aes = Aes.Create())
            {
                Rfc2898DeriveBytes rfc2898DeriveBytes = new Rfc2898DeriveBytes(password, new byte[]
                {
            73,
            118,
            97,
            110,
            32,
            77,
            101,
            100,
            118,
            101,
            100,
            101,
            118
                });
                aes.Key = rfc2898DeriveBytes.GetBytes(32);
                aes.IV = rfc2898DeriveBytes.GetBytes(16);
                using (FileStream fileStream = new FileStream(A_1, FileMode.Create))
                {
                    using (CryptoStream cryptoStream = new CryptoStream(fileStream, aes.CreateEncryptor(), CryptoStreamMode.Write))
                    {
                        using (FileStream fileStream2 = new FileStream(A_0, FileMode.Open))
                        {
                            int num;
                            while ((num = fileStream2.ReadByte()) != -1)
                            {
                                cryptoStream.WriteByte((byte)num);
                            }
                        }
                    }
                }
            }
        }


        public static bool EncryptFilesTOPGRID(string folderin)
        {
            new List<string>();
            bool result;
            try
            {
                string text = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/progGrid.rzzr");
                string text2 = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/progGrid.cerzzr");
                u00A0(text, text2);
                //string text3 = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/progGridM.rzzr");
                //text2 = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/progGridM.cerzzr");
                //u00A0(text3, text2);
                string text4 = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/progBLL.cz");
                text2 = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/progBLL.ce");
                u00A0(text4, text2);
                string text5 = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/progController.cz");
                text2 = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/progController.ce");
                u00A0(text5, text2);
                string text6 = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/progDialog.rzzr");
                text2 = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/progDialog.cerzzr");
                u00A0(text6, text2);
                //string text7 = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/progDialogM.rzzr");
                //text2 = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/progDialogM.cerzzr");
                //u00A0(text7, text2);
                string text8 = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/colCombo.rzzr");
                text2 = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/colCombo.cerzzr");
                u00A0(text8, text2);
                string text9 = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/colComboM.rzzr");
                text2 = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/colComboM.cerzzr");
                u00A0(text9, text2);
                string text10 = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/colautoCombo.rzzr");
                text2 = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/colautoCombo.cerzzr");
                u00A0(text10, text2);
                string text11 = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/colautoComboM.rzzr");
                text2 = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/colautoComboM.cerzzr");
                u00A0(text11, text2);
                string text12 = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/progViewModel.cz");
                text2 = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/progViewModel.ce");
                u00A0(text12, text2);
                string text13 = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/colViewModel.cz");
                text2 = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/colViewModel.ce");
                u00A0(text13, text2);
                string text14 = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/colautoViewModel.cz");
                text2 = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/colautoViewModel.ce");
                u00A0(text14, text2);
                string text15 = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/colBLL.cz");
                text2 = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/colBLL.ce");
                u00A0(text15, text2);
                string text16 = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/colController.cz");
                text2 = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/colController.ce");
                u00A0(text16, text2);
                string text17 = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/colautoBLL.cz");
                text2 = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/colautoBLL.ce");
                u00A0(text17, text2);
                string text18 = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/colautoController.cz");
                text2 = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/colautoController.ce");
                u00A0(text18, text2);
                string text19 = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/projMod.cz");
                text2 = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/projMod.ce");
                u00A0(text19, text2);
                string text20 = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/projModM.cz");
                text2 = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/projModM.ce");
                u00A0(text20, text2);
                string text21 = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/colMod.cz");
                text2 = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/colMod.ce");
                u00A0(text21, text2);
                string text22 = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/colModM.cz");
                text2 = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/colModM.ce");
                u00A0(text22, text2);
                string text23 = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/colautoMod.cz");
                text2 = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/colautoMod.ce");
                u00A0(text23, text2);
                string text24 = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/colautoModM.cz");
                text2 = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/colautoModM.ce");
                u00A0(text24, text2);
                result = true;
            }
            catch (Exception)
            {
                result = false;
            }
            return result;
        }


        public static bool GenerateCOMBOAUTORFIRST(string folderin, string projstr, string progstr, string strpkid, string column1str, string column1type, string column2str, string column2type, string column3str, string column3type, string column4str, string column4type, string column5str, string column5type, string column6str, string column6type, string column7str, string column7type, string column8str, string column8type, string column9str, string column9type, string column10str, string column10type, string column11str, string column11type, string childprog1str, string childprog2str, string strcomboclicked, string comboprogstr, string stradoefcombo, string tablestr, string strchild1pkid, string childchildprogstr, string strchildchild1pkid)
        {
            bool result;
            try
            {
                string text = folderin.Replace("KalWasm\\Server\\", "KalMauWasm\\");

                string text2 = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/colautoMod.ce");
                string text3 = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/colautoMod.ck");
                u1680(text2, text3);
                u2001(folderin, "Gen_Code/TOPGRID/colautoMod.ck", "col1", column1type);
                string path = "Gen_Code/TOPGRID/" + comboprogstr + "autoMod.ck";
                string text4 = System.IO.Path.Combine(folderin, path);
                string text5 = System.IO.File.ReadAllText(text3);
                text5 = text5.Replace("~prog~", progstr);
                text5 = text5.Replace("~proj~", projstr);
                text5 = text5.Replace("~combotable~", tablestr);
                text5 = text5.Replace("~columpk~", strpkid);
                text5 = text5.Replace("~tablecolumin~", comboprogstr);
                text5 = u00A0(text5, column1str, column1type, 1);
                System.IO.File.WriteAllText(text4, text5);
                string text6 = folderin + progstr + "UI";
                text6 = text6.Replace("Server", "Shared");
                if (!Directory.Exists(text6))
                {
                    Directory.CreateDirectory(text6);
                }
                string text7 = string.Concat(new string[]
                {
            progstr,
            "UI/",
            progstr,
            comboprogstr,
            "autoMod.cs"
                });
                string text8 = System.IO.Path.Combine(folderin, text7);
                text8 = text8.Replace("Server", "Shared");
                System.IO.File.Copy(text4, text8, true);
                System.IO.File.Delete(text4);
                System.IO.File.Delete(text3);  //kle
                string text9 = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/colautoModM.ce");
                text3 = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/colautoModM.ck");
                u1680(text9, text3);
                u2001(folderin, "Gen_Code/TOPGRID/colautoModM.ck", "col1", column1type);
                path = "Gen_Code/TOPGRID/" + comboprogstr + "autoModM.ck";
                text4 = System.IO.Path.Combine(folderin, path);
                text5 = System.IO.File.ReadAllText(text3);
                text5 = text5.Replace("~prog~", progstr);
                text5 = text5.Replace("~proj~", projstr);
                text5 = text5.Replace("~combotable~", tablestr);
                text5 = text5.Replace("~columpk~", strpkid);
                text5 = text5.Replace("~tablecolumin~", comboprogstr);
                text5 = u00A0(text5, column1str, column1type, 1);
                System.IO.File.WriteAllText(text4, text5);
                text6 = text + "Data/" + progstr + "UI";
                if (!Directory.Exists(text6))
                {
                    Directory.CreateDirectory(text6);
                }
                text7 = string.Concat(new string[]
                {
            text,
            "Data/",
            progstr,
            "UI/",
            progstr,
            comboprogstr,
            "autoMod.cs"
                });
                text8 = text7;
                System.IO.File.Copy(text4, text8, true);
                System.IO.File.Delete(text4);
                System.IO.File.Delete(text3);  //kle
                string text10 = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/colautoViewModel.ce");
                text3 = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/colautoViewModel.ck");
                u1680(text10, text3);
                path = "Gen_Code/TOPGRID/" + comboprogstr + "autoViewModel.ck";
                text4 = System.IO.Path.Combine(folderin, path);
                text5 = System.IO.File.ReadAllText(text3);
                text5 = text5.Replace("~proj~", projstr);
                text5 = text5.Replace("~prog~", progstr);
                text5 = text5.Replace("~tablecolumin~", comboprogstr);
                text5 = text5.Replace("~combotable~", tablestr);
                System.IO.File.WriteAllText(text4, text5);
                text6 = folderin + "Models/" + progstr + "UI";
                if (!Directory.Exists(text6))
                {
                    Directory.CreateDirectory(text6);
                }
                text7 = string.Concat(new string[]
                {
            "Models/",
            progstr,
            "UI/",
            progstr,
            comboprogstr,
            "autoViewModels.cs"
                });
                text8 = System.IO.Path.Combine(folderin, text7);
                System.IO.File.Copy(text4, text8, true);
                System.IO.File.Delete(text4);
                System.IO.File.Delete(text3);  //kle
                result = true;
            }
            catch (Exception ex)
            {
                string message = ex.Message;
                result = false;
            }
            return result;
        }


        public static bool GenerateCOMBOAUTOSECOND(string folderin, string projstr, string progstr, string strpkid, string column1str, string column1type, string column2str, string column2type, string column3str, string column3type, string column4str, string column4type, string column5str, string column5type, string column6str, string column6type, string column7str, string column7type, string column8str, string column8type, string column9str, string column9type, string column10str, string column10type, string column11str, string column11type, string childprog1str, string childprog2str, string strcomboclicked, string comboprogstr, string stradoefcombo, string tablestr, string strchild1pkid, string childchildprogstr, string strchildchild1pkid)
        {
            bool result;
            try
            {
                string text = folderin.Replace("KalWasm\\Server\\", "KalMauWasm\\");

                string text2 = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/colautoBLL.ce");
                string text3 = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/colautoBLL.ck");
                u1680(text2, text3);
                u2001(folderin, "Gen_Code/TOPGRID/colautoBLL.ck", "col1", column1type);
                string path = "Gen_Code/TOPGRID/" + comboprogstr + "autoBLL.ck";
                string text4 = System.IO.Path.Combine(folderin, path);
                string text5 = System.IO.File.ReadAllText(text3);
                text5 = text5.Replace("~proj~", projstr);
                text5 = text5.Replace("~prog~", progstr);
                text5 = text5.Replace("~combotable~", tablestr);
                text5 = text5.Replace("~tablecolumin~", comboprogstr);
                text5 = text5.Replace("~columpk~", strpkid);
                text5 = text5.Replace("~column1~", column1str);
                System.IO.File.WriteAllText(text4, text5);
                string text6 = folderin + progstr + "UI";
                if (!Directory.Exists(text6))
                {
                    Directory.CreateDirectory(text6);
                }
                string text7 = string.Concat(new string[]
                {
            progstr,
            "UI/",
            progstr,
            comboprogstr,
            "autoBLL.cs"
                });
                string text8 = System.IO.Path.Combine(folderin, text7);
                System.IO.File.Copy(text4, text8, true);
                System.IO.File.Delete(text4);
                System.IO.File.Delete(text3);  //kle
                string text9 = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/colautoController.ce");
                text3 = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/colautoController.ck");
                u1680(text9, text3);
                path = "Gen_Code/TOPGRID/" + comboprogstr + "autoController.ck";
                text4 = System.IO.Path.Combine(folderin, path);
                text5 = System.IO.File.ReadAllText(text3);
                text5 = text5.Replace("~proj~", projstr);
                text5 = text5.Replace("~prog~", progstr);
                text5 = text5.Replace("~combotable~", tablestr);
                text5 = text5.Replace("~tablecolumin~", comboprogstr);
                System.IO.File.WriteAllText(text4, text5);
                text6 = folderin + "Controllers/" + progstr + "UI";
                if (!Directory.Exists(text6))
                {
                    Directory.CreateDirectory(text6);
                }
                text7 = string.Concat(new string[]
                {
            "Controllers/",
            progstr,
            "UI/",
            progstr,
            comboprogstr,
            "autoController.cs"
                });
                text8 = System.IO.Path.Combine(folderin, text7);
                System.IO.File.Copy(text4, text8, true);
                System.IO.File.Delete(text4);
                System.IO.File.Delete(text3);  //kle
                string text10 = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/colautoCombo.cerzzr");
                text3 = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/colautoCombo.rzzk");
                u1680(text10, text3);
                path = "Gen_Code/TOPGRID/" + comboprogstr + "autoCombo.rzzk";
                text4 = System.IO.Path.Combine(folderin, path);
                text5 = System.IO.File.ReadAllText(text3);
                text5 = text5.Replace("~prog~", progstr);
                text5 = text5.Replace("~proj~", projstr);
                text5 = text5.Replace("~combotable~", tablestr);
                text5 = text5.Replace("~tablecolumin~", comboprogstr);
                text5 = text5.Replace("~columpk~", strpkid);
                text5 = text5.Replace("~column1~", column1str);
                System.IO.File.WriteAllText(text4, text5);
                text6 = folderin + "Shared/" + progstr + "UI";
                text6 = text6.Replace("Server", "Client");
                if (!Directory.Exists(text6))
                {
                    Directory.CreateDirectory(text6);
                }
                text7 = string.Concat(new string[]
                {
            "Shared/",
            progstr,
            "UI/",
            progstr,
            comboprogstr,
            "autoCombo.razor"
                });
                text8 = System.IO.Path.Combine(folderin, text7);
                text8 = text8.Replace("Server", "Client");
                System.IO.File.Copy(text4, text8, true);
                System.IO.File.Delete(text4);
                System.IO.File.Delete(text3);  //kle
                string text11 = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/colautoComboM.cerzzr");
                text3 = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/colautoComboM.rzzk");
                u1680(text11, text3);
                path = "Gen_Code/TOPGRID/" + comboprogstr + "autoComboM.rzzk";
                text4 = System.IO.Path.Combine(folderin, path);
                text5 = System.IO.File.ReadAllText(text3);
                text5 = text5.Replace("~prog~", progstr);
                text5 = text5.Replace("~proj~", projstr);
                text5 = text5.Replace("~combotable~", tablestr);
                text5 = text5.Replace("~tablecolumin~", comboprogstr);
                text5 = text5.Replace("~columpk~", strpkid);
                text5 = text5.Replace("~column1~", column1str);
                System.IO.File.WriteAllText(text4, text5);
                text6 = text + "Shared/" + progstr + "UI";
                if (!Directory.Exists(text6))
                {
                    Directory.CreateDirectory(text6);
                }
                text7 = string.Concat(new string[]
                {
            text,
            "Shared/",
            progstr,
            "UI/",
            progstr,
            comboprogstr,
            "autoCombo.razor"
                });
                text8 = text7;
                System.IO.File.Copy(text4, text8, true);
                System.IO.File.Delete(text4);
                System.IO.File.Delete(text3);  //kle
                result = true;
            }
            catch (Exception ex)
            {
                string message = ex.Message;
                result = false;
            }
            return result;
        }

        public static bool GenerateCOMBOFIRST(string folderin, string projstr, string progstr, string strpkid, string column1str, string column1type, string column2str, string column2type, string column3str, string column3type, string column4str, string column4type, string column5str, string column5type, string column6str, string column6type, string column7str, string column7type, string column8str, string column8type, string column9str, string column9type, string column10str, string column10type, string column11str, string column11type, string childprog1str, string childprog2str, string strcomboclicked, string comboprogstr, string stradoefcombo, string tablestr, string strchild1pkid, string childchildprogstr, string strchildchild1pkid)
        {
            bool result;
            try
            {
                string text = folderin.Replace("KalWasm\\Server\\", "KalMauWasm\\");

                string text2 = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/colMod.ce");
                string text3 = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/colMod.ck");
                u1680(text2, text3);
                u2001(folderin, "Gen_Code/TOPGRID/colMod.ck", "col1", column1type);
                string path = "Gen_Code/TOPGRID/" + comboprogstr + "Mod.ck";
                string text4 = System.IO.Path.Combine(folderin, path);
                string text5 = System.IO.File.ReadAllText(text3);
                text5 = text5.Replace("~prog~", progstr);
                text5 = text5.Replace("~proj~", projstr);
                text5 = text5.Replace("~combotable~", tablestr);
                text5 = text5.Replace("~columpk~", strpkid);
                text5 = text5.Replace("~tablecolumin~", comboprogstr);
                text5 = u00A0(text5, column1str, column1type, 1);
                System.IO.File.WriteAllText(text4, text5);
                string text6 = folderin + progstr + "UI";
                text6 = text6.Replace("Server", "Shared");
                if (!Directory.Exists(text6))
                {
                    Directory.CreateDirectory(text6);
                }
                string text7 = string.Concat(new string[]
                {
            progstr,
            "UI/",
            progstr,
            comboprogstr,
            "Mod.cs"
                });
                string text8 = System.IO.Path.Combine(folderin, text7);
                text8 = text8.Replace("Server", "Shared");
                System.IO.File.Copy(text4, text8, true);
                System.IO.File.Delete(text4);
                System.IO.File.Delete(text3);  //kle
                string text9 = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/colModM.ce");
                text3 = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/colModM.ck");
                u1680(text9, text3);
                u2001(folderin, "Gen_Code/TOPGRID/colModM.ck", "col1", column1type);
                path = "Gen_Code/TOPGRID/" + comboprogstr + "ModM.ck";
                text4 = System.IO.Path.Combine(folderin, path);
                text5 = System.IO.File.ReadAllText(text3);
                text5 = text5.Replace("~prog~", progstr);
                text5 = text5.Replace("~proj~", projstr);
                text5 = text5.Replace("~combotable~", tablestr);
                text5 = text5.Replace("~columpk~", strpkid);
                text5 = text5.Replace("~tablecolumin~", comboprogstr);
                text5 = u00A0(text5, column1str, column1type, 1);
                System.IO.File.WriteAllText(text4, text5);
                text6 = text + "Data/" + progstr + "UI";
                if (!Directory.Exists(text6))
                {
                    Directory.CreateDirectory(text6);
                }
                text7 = string.Concat(new string[]
                {
            text,
            "Data/",
            progstr,
            "UI/",
            progstr,
            comboprogstr,
            "Mod.cs"
                });
                text8 = text7;
                System.IO.File.Copy(text4, text8, true);
                System.IO.File.Delete(text4);
                System.IO.File.Delete(text3);  //kle
                string text10 = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/colViewModel.ce");
                text3 = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/colViewModel.ck");
                u1680(text10, text3);
                path = "Gen_Code/TOPGRID/" + comboprogstr + "ViewModel.ck";
                text4 = System.IO.Path.Combine(folderin, path);
                text5 = System.IO.File.ReadAllText(text3);
                text5 = text5.Replace("~proj~", projstr);
                text5 = text5.Replace("~prog~", progstr);
                text5 = text5.Replace("~tablecolumin~", comboprogstr);
                text5 = text5.Replace("~combotable~", tablestr);
                System.IO.File.WriteAllText(text4, text5);
                text6 = folderin + "Models/" + progstr + "UI";
                if (!Directory.Exists(text6))
                {
                    Directory.CreateDirectory(text6);
                }
                text7 = string.Concat(new string[]
                {
            "Models/",
            progstr,
            "UI/",
            progstr,
            comboprogstr,
            "ViewModels.cs"
                });
                text8 = System.IO.Path.Combine(folderin, text7);
                System.IO.File.Copy(text4, text8, true);
                System.IO.File.Delete(text4);
                System.IO.File.Delete(text3);  //kle
                result = true;
            }
            catch (Exception ex)
            {
                string message = ex.Message;
                result = false;
            }
            return result;
        }

        public static bool GenerateCOMBORSECOND(string folderin, string projstr, string progstr, string strpkid, string column1str, string column1type, string column2str, string column2type, string column3str, string column3type, string column4str, string column4type, string column5str, string column5type, string column6str, string column6type, string column7str, string column7type, string column8str, string column8type, string column9str, string column9type, string column10str, string column10type, string column11str, string column11type, string childprog1str, string childprog2str, string strcomboclicked, string comboprogstr, string stradoefcombo, string tablestr, string strchild1pkid, string childchildprogstr, string strchildchild1pkid)
        {
            bool result;
            try
            {
                string text = folderin.Replace("KalWasm\\Server\\", "KalMauWasm\\");

                string text2 = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/colBLL.ce");
                string text3 = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/colBLL.ck");
                u1680(text2, text3);
                u2001(folderin, "Gen_Code/TOPGRID/colBLL.ck", "col1", column1type);
                string path = "Gen_Code/TOPGRID/" + comboprogstr + "BLL.ck";
                string text4 = System.IO.Path.Combine(folderin, path);
                string text5 = System.IO.File.ReadAllText(text3);
                text5 = text5.Replace("~proj~", projstr);
                text5 = text5.Replace("~prog~", progstr);
                text5 = text5.Replace("~combotable~", tablestr);
                text5 = text5.Replace("~tablecolumin~", comboprogstr);
                text5 = text5.Replace("~columpk~", strpkid);
                text5 = text5.Replace("~column1~", column1str);
                System.IO.File.WriteAllText(text4, text5);
                string text6 = folderin + progstr + "UI";
                if (!Directory.Exists(text6))
                {
                    Directory.CreateDirectory(text6);
                }
                string text7 = string.Concat(new string[]
                {
            progstr,
            "UI/",
            progstr,
            comboprogstr,
            "BLL.cs"
                });
                string text8 = System.IO.Path.Combine(folderin, text7);
                System.IO.File.Copy(text4, text8, true);
                System.IO.File.Delete(text4);
                System.IO.File.Delete(text3);  //kle
                string text9 = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/colController.ce");
                text3 = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/colController.ck");
                u1680(text9, text3);
                path = "Gen_Code/TOPGRID/" + comboprogstr + "Controller.ck";
                text4 = System.IO.Path.Combine(folderin, path);
                text5 = System.IO.File.ReadAllText(text3);
                text5 = text5.Replace("~proj~", projstr);
                text5 = text5.Replace("~prog~", progstr);
                text5 = text5.Replace("~combotable~", tablestr);
                text5 = text5.Replace("~tablecolumin~", comboprogstr);
                System.IO.File.WriteAllText(text4, text5);
                text6 = folderin + "Controllers/" + progstr + "UI";
                if (!Directory.Exists(text6))
                {
                    Directory.CreateDirectory(text6);
                }
                text7 = string.Concat(new string[]
                {
            "Controllers/",
            progstr,
            "UI/",
            progstr,
            comboprogstr,
            "Controller.cs"
                });
                text8 = System.IO.Path.Combine(folderin, text7);
                System.IO.File.Copy(text4, text8, true);
                System.IO.File.Delete(text4);
                System.IO.File.Delete(text3);  //kle
                string text10 = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/colCombo.cerzzr");
                text3 = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/colCombo.rzzk");
                u1680(text10, text3);
                path = "Gen_Code/TOPGRID/" + comboprogstr + "Combo.rzzk";
                text4 = System.IO.Path.Combine(folderin, path);
                text5 = System.IO.File.ReadAllText(text3);
                text5 = text5.Replace("~prog~", progstr);
                text5 = text5.Replace("~proj~", projstr);
                text5 = text5.Replace("~combotable~", tablestr);
                text5 = text5.Replace("~tablecolumin~", comboprogstr);
                text5 = text5.Replace("~columpk~", strpkid);
                text5 = text5.Replace("~column1~", column1str);
                System.IO.File.WriteAllText(text4, text5);
                text6 = folderin + "Shared/" + progstr + "UI";
                text6 = text6.Replace("Server", "Client");
                if (!Directory.Exists(text6))
                {
                    Directory.CreateDirectory(text6);
                }
                text7 = string.Concat(new string[]
                {
            "Shared/",
            progstr,
            "UI/",
            progstr,
            comboprogstr,
            "Combo.razor"
                });
                text8 = System.IO.Path.Combine(folderin, text7);
                text8 = text8.Replace("Server", "Client");
                System.IO.File.Copy(text4, text8, true);
                System.IO.File.Delete(text4);
                System.IO.File.Delete(text3);   //kle
                string text11 = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/colComboM.cerzzr");
                text3 = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/colComboM.rzzk");
                u1680(text11, text3);
                path = "Gen_Code/TOPGRID/" + comboprogstr + "ComboM.rzzk";
                text4 = System.IO.Path.Combine(folderin, path);
                text5 = System.IO.File.ReadAllText(text3);
                text5 = text5.Replace("~prog~", progstr);
                text5 = text5.Replace("~proj~", projstr);
                text5 = text5.Replace("~combotable~", tablestr);
                text5 = text5.Replace("~tablecolumin~", comboprogstr);
                text5 = text5.Replace("~columpk~", strpkid);
                text5 = text5.Replace("~column1~", column1str);
                System.IO.File.WriteAllText(text4, text5);
                text6 = text + "Shared/" + progstr + "UI";
                if (!Directory.Exists(text6))
                {
                    Directory.CreateDirectory(text6);
                }
                text7 = string.Concat(new string[]
                {
            text,
            "Shared/",
            progstr,
            "UI/",
            progstr,
            comboprogstr,
            "Combo.razor"
                });
                text8 = text7;
                System.IO.File.Copy(text4, text8, true);
                System.IO.File.Delete(text4);
                System.IO.File.Delete(text3);  //kle
                result = true;
            }
            catch (Exception ex)
            {
                string message = ex.Message;
                result = false;
            }
            return result;
        }


        public static bool GenerateTOPGRIDFIRST(string folderin, string projstr, string progstr, string strpkid, string column1str, string column1type, string column2str, string column2type, string column3str, string column3type, string column4str, string column4type, string column5str, string column5type, string column6str, string column6type, string column7str, string column7type, string column8str, string column8type, string column9str, string column9type, string column10str, string column10type, string column11str, string column11type, string childprog1str, string childprog2str, string strcomboclicked, string comboprogstr, string stradoefcombo, string tablestr, string strchild1pkid, string childchildprogstr, string strchildchild1pkid, string strdropcol1In, string strdropcol2In, string strdropcol3In, string strdropcol4In, string strdropcol5In, string strdropcol6In, string strautodropcol1In, string strautodropcol2In, string strautodropcol3In, string strautodropcol4In, string strautodropcol5In, string strautodropcol6In)
        {
            bool result;
            try
            {

                //------------------------------------------------------------------------------------
                //-- doing the Models here FIRST -----------------------------------------------------
                //------------------------------------------------------------------------------------

                string text7 = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/projMod.cz");
                string text2 = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/projMod.ck");
                System.IO.File.Copy(text7, text2, true);

                u2001(folderin, "Gen_Code/TOPGRID/projMod.ck", "col1", column1type);
                u2001(folderin, "Gen_Code/TOPGRID/projMod.ck", "col2", column2type);
                u2001(folderin, "Gen_Code/TOPGRID/projMod.ck", "col3", column3type);
                u2001(folderin, "Gen_Code/TOPGRID/projMod.ck", "col4", column4type);
                u2001(folderin, "Gen_Code/TOPGRID/projMod.ck", "col5", column5type);
                u2001(folderin, "Gen_Code/TOPGRID/projMod.ck", "col6", column6type);
                u2001(folderin, "Gen_Code/TOPGRID/projMod.ck", "col7", column7type);
                u2001(folderin, "Gen_Code/TOPGRID/projMod.ck", "col8", column8type);
                u2001(folderin, "Gen_Code/TOPGRID/projMod.ck", "col9", column9type);
                u2001(folderin, "Gen_Code/TOPGRID/projMod.ck", "col10", column10type);
                u2001(folderin, "Gen_Code/TOPGRID/projMod.ck", "col11", column11type);
                string path = "Gen_Code/TOPGRID/" + progstr + "Mod.ck";
                string text3 = System.IO.Path.Combine(folderin, path);
                string text4 = System.IO.File.ReadAllText(text2);
                text4 = text4.Replace("~prog~", progstr);
                text4 = text4.Replace("~proj~", projstr);
                text4 = text4.Replace("~tablemodel~", tablestr);
                text4 = text4.Replace("~PK_ID~", strpkid);
                text4 = u00A0(text4, column1str, column1type, 1);
                text4 = u00A0(text4, column2str, column2type, 2);
                text4 = u00A0(text4, column3str, column3type, 3);
                text4 = u00A0(text4, column4str, column4type, 4);
                text4 = u00A0(text4, column5str, column5type, 5);
                text4 = u00A0(text4, column6str, column6type, 6);
                text4 = u00A0(text4, column7str, column7type, 7);
                text4 = u00A0(text4, column8str, column8type, 8);
                text4 = u00A0(text4, column9str, column9type, 9);
                text4 = u00A0(text4, column10str, column10type, 10);
                text4 = u00A0(text4, column11str, column11type, 11);
                System.IO.File.WriteAllText(text3, text4);
                string path2 = "Models/" + tablestr + ".cs";  //new
                string text6 = System.IO.Path.Combine(folderin, path2);
                //text6 = text6.Replace("Server", "Shared");
                System.IO.File.Copy(text3, text6, true);
                System.IO.File.Delete(text3);
                System.IO.File.Delete(text2);  //kle




                //-----------------------------------------------------------------------
                //First check if model already exists in ApplicationDbContext.cs file

                string path42 = "Data/ApplicationDbContext.cs";
                string text62 = System.IO.Path.Combine(folderin, path42);
                string text82 = string.Concat(new string[]
                {
                    "public DbSet<" + tablestr + "> " + tablestr + " => Set<" + tablestr + ">();"

                });

                string foundModel = "no";  //for testing
                var index = 0;
                foreach (var line in System.IO.File.ReadAllLines(text62))
                {
                    if (line.Contains(text82, StringComparison.OrdinalIgnoreCase))
                    {
                        //results.Add($"Line {lineNumber}: {line}");
                        foundModel = "yes";
                    }
                    index++;
                    
                }

                if (foundModel == "no")
                {
                    u00A0(folderin, text62, "ADDMODELHERE", text82);
                }




                //------------------------------------------------------------------------------------
                //-- doing the Grid Popup Dialog Page here --------------------------------------------------------
                //------------------------------------------------------------------------------------

                string text9 = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/progDialog.rzzr");
                text2 = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/progDialog.rzzk");
                System.IO.File.Copy(text9, text2, true);

                u2001(folderin, "Gen_Code/TOPGRID/progDialog.rzzk", "col1", column1type);
                u2001(folderin, "Gen_Code/TOPGRID/progDialog.rzzk", "col2", column2type);
                u2001(folderin, "Gen_Code/TOPGRID/progDialog.rzzk", "col3", column3type);
                u2001(folderin, "Gen_Code/TOPGRID/progDialog.rzzk", "col4", column4type);
                u2001(folderin, "Gen_Code/TOPGRID/progDialog.rzzk", "col5", column5type);
                u2001(folderin, "Gen_Code/TOPGRID/progDialog.rzzk", "col6", column6type);
                u2001(folderin, "Gen_Code/TOPGRID/progDialog.rzzk", "col7", column7type);
                u2001(folderin, "Gen_Code/TOPGRID/progDialog.rzzk", "col8", column8type);
                u2001(folderin, "Gen_Code/TOPGRID/progDialog.rzzk", "col9", column9type);
                u2001(folderin, "Gen_Code/TOPGRID/progDialog.rzzk", "col10", column10type);
                u2001(folderin, "Gen_Code/TOPGRID/progDialog.rzzk", "col11", column11type);
                path = "Gen_Code/TOPGRID/" + progstr + "Dialog.rzzk";
                text3 = System.IO.Path.Combine(folderin, path);
                text4 = System.IO.File.ReadAllText(text2);
                text4 = text4.Replace("~prog~", progstr);
                text4 = text4.Replace("~proj~", projstr);
                text4 = text4.Replace("~tablemodel~", tablestr);
                text4 = u00A0(text4, column1str, column1type, 1);
                text4 = u00A0(text4, column2str, column2type, 2);
                text4 = u00A0(text4, column3str, column3type, 3);
                text4 = u00A0(text4, column4str, column4type, 4);
                text4 = u00A0(text4, column5str, column5type, 5);
                text4 = u00A0(text4, column6str, column6type, 6);
                text4 = u00A0(text4, column7str, column7type, 7);
                text4 = u00A0(text4, column8str, column8type, 8);
                text4 = u00A0(text4, column9str, column9type, 9);
                text4 = u00A0(text4, column10str, column10type, 10);
                text4 = u00A0(text4, column11str, column11type, 11);
                System.IO.File.WriteAllText(text3, text4);

                string text5 = folderin + "Components/Pages/" + progstr + "UI";
                //text5 = text5.Replace("Server", "Client");
                if (!Directory.Exists(text5))
                {
                    Directory.CreateDirectory(text5);
                }
                path2 = string.Concat(new string[]
                {
            "Components/Pages/",
            progstr,
            "UI/",
            progstr,
            "Dialog.razor"
                });
                text6 = System.IO.Path.Combine(folderin, path2);
                //text6 = text6.Replace("Server", "Client");
                System.IO.File.Copy(text3, text6, true);
                System.IO.File.Delete(text3);
                System.IO.File.Delete(text2);  //kle




                //------------------------------------------------------------------------------------
                //-- doing the Grid Page here --------------------------------------------------------
                //------------------------------------------------------------------------------------

                string text = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/progGrid.rzzr");
                text2 = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/progGrid.rzzk");
                System.IO.File.Copy(text, text2, true);

                u2001(folderin, "Gen_Code/TOPGRID/progGrid.rzzk", "col1", column1type);
                u2001(folderin, "Gen_Code/TOPGRID/progGrid.rzzk", "col2", column2type);
                u2001(folderin, "Gen_Code/TOPGRID/progGrid.rzzk", "col3", column3type);
                u2001(folderin, "Gen_Code/TOPGRID/progGrid.rzzk", "col4", column4type);
                u2001(folderin, "Gen_Code/TOPGRID/progGrid.rzzk", "col5", column5type);
                u2001(folderin, "Gen_Code/TOPGRID/progGrid.rzzk", "col6", column6type);
                u2001(folderin, "Gen_Code/TOPGRID/progGrid.rzzk", "col7", column7type);
                u2001(folderin, "Gen_Code/TOPGRID/progGrid.rzzk", "col8", column8type);
                u2001(folderin, "Gen_Code/TOPGRID/progGrid.rzzk", "col9", column9type);
                u2001(folderin, "Gen_Code/TOPGRID/progGrid.rzzk", "col10", column10type);
                u2001(folderin, "Gen_Code/TOPGRID/progGrid.rzzk", "col11", column11type);
                path = "Gen_Code/TOPGRID/" + progstr + "Grid.rzzk";
                text3 = System.IO.Path.Combine(folderin, path);
                text4 = System.IO.File.ReadAllText(text2);
                text4 = text4.Replace("~prog~", progstr);
                text4 = text4.Replace("~proglower~", progstr.ToLower());
                text4 = text4.Replace("~proj~", projstr);
                text4 = text4.Replace("~tablemodel~", tablestr);
                text4 = text4.Replace("~PK_ID~", strpkid);
                text4 = u00A0(text4, column1str, column1type, 1);
                text4 = u00A0(text4, column2str, column2type, 2);
                text4 = u00A0(text4, column3str, column3type, 3);
                text4 = u00A0(text4, column4str, column4type, 4);
                text4 = u00A0(text4, column5str, column5type, 5);
                text4 = u00A0(text4, column6str, column6type, 6);
                text4 = u00A0(text4, column7str, column7type, 7);
                text4 = u00A0(text4, column8str, column8type, 8);
                text4 = u00A0(text4, column9str, column9type, 9);
                text4 = u00A0(text4, column10str, column10type, 10);
                text4 = u00A0(text4, column11str, column11type, 11);
                System.IO.File.WriteAllText(text3, text4);
                text5 = folderin + "Components/Pages/" + progstr + "UI";
                if (!Directory.Exists(text5))
                {
                    Directory.CreateDirectory(text5);
                }
                path2 = string.Concat(new string[]
                {
            "Components/Pages/",
            progstr,
            "UI/",
            progstr,
            "Grid.razor"
                });
                text6 = System.IO.Path.Combine(folderin, path2);
                System.IO.File.Copy(text3, text6, true);
                System.IO.File.Delete(text3);
                System.IO.File.Delete(text2); 




                //------------------------------------------------------------------------------------
                //-- doing the Menu link adding here --------------------------------------------------------
                //------------------------------------------------------------------------------------

                string path32 = "Components/Layout/NavMenu.razor";
                string text52 = System.IO.Path.Combine(folderin, path32);
                //text52 = text52.Replace("Server", "Client");
                string text72 = string.Concat(new string[]
                {
            "<div class='nav-item px-3'><NavLink class='nav-link' href='",
            progstr.ToLower(),
            "grid'><span class='bi bi-list-nested-nav-menu' aria-hidden='true'></span>",
            progstr,
            "</NavLink></div>"
                });
                u00A0(folderin, text52, "ADDLINKHERE", text72);


                result = true;

            }
            catch (Exception ex)
            {
                string message = ex.Message;
                result = false;
            }
            return result;
        }


        public static bool GenerateTOPGRIDSECOND(string folderin, string projstr, string progstr, string strpkid, string column1str, string column1type, string column2str, string column2type, string column3str, string column3type, string column4str, string column4type, string column5str, string column5type, string column6str, string column6type, string column7str, string column7type, string column8str, string column8type, string column9str, string column9type, string column10str, string column10type, string column11str, string column11type, string childprog1str, string childprog2str, string strcomboclicked, string comboprogstr, string stradoefcombo, string tablestr, string strchild1pkid, string childchildprogstr, string strchildchild1pkid)
        {
            bool result;
            try
            {
                string text = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/progBLL.ce");
                string text2 = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/progBLL.ck");
                u1680(text, text2);
                u2001(folderin, "Gen_Code/TOPGRID/progBLL.ck", "col1", column1type);
                u2001(folderin, "Gen_Code/TOPGRID/progBLL.ck", "col2", column2type);
                u2001(folderin, "Gen_Code/TOPGRID/progBLL.ck", "col3", column3type);
                u2001(folderin, "Gen_Code/TOPGRID/progBLL.ck", "col4", column4type);
                u2001(folderin, "Gen_Code/TOPGRID/progBLL.ck", "col5", column5type);
                u2001(folderin, "Gen_Code/TOPGRID/progBLL.ck", "col6", column6type);
                u2001(folderin, "Gen_Code/TOPGRID/progBLL.ck", "col7", column7type);
                u2001(folderin, "Gen_Code/TOPGRID/progBLL.ck", "col8", column8type);
                u2001(folderin, "Gen_Code/TOPGRID/progBLL.ck", "col9", column9type);
                u2001(folderin, "Gen_Code/TOPGRID/progBLL.ck", "col10", column10type);
                u2001(folderin, "Gen_Code/TOPGRID/progBLL.ck", "col11", column11type);
                string path = "Gen_Code/TOPGRID/" + progstr + "BLL.ck";
                string text3 = System.IO.Path.Combine(folderin, path);
                string text4 = System.IO.File.ReadAllText(text2);
                text4 = text4.Replace("~proj~", projstr);
                text4 = text4.Replace("~prog~", progstr);
                text4 = text4.Replace("~tablemodel~", tablestr);
                text4 = text4.Replace("~table~", tablestr);
                text4 = text4.Replace("~PK_ID~", strpkid);
                text4 = u00A0(text4, column1str, column1type, 1);
                text4 = u00A0(text4, column2str, column2type, 2);
                text4 = u00A0(text4, column3str, column3type, 3);
                text4 = u00A0(text4, column4str, column4type, 4);
                text4 = u00A0(text4, column5str, column5type, 5);
                text4 = u00A0(text4, column6str, column6type, 6);
                text4 = u00A0(text4, column7str, column7type, 7);
                text4 = u00A0(text4, column8str, column8type, 8);
                text4 = u00A0(text4, column9str, column9type, 9);
                text4 = u00A0(text4, column10str, column10type, 10);
                text4 = u00A0(text4, column11str, column11type, 11);
                System.IO.File.WriteAllText(text3, text4);
                string path2 = folderin + progstr + "UI";
                if (!Directory.Exists(path2))
                {
                    Directory.CreateDirectory(path2);
                }
                string path3 = progstr + "UI/" + progstr + "BLL.cs";
                string text5 = System.IO.Path.Combine(folderin, path3);
                System.IO.File.Copy(text3, text5, true);
                System.IO.File.Delete(text3);
                System.IO.File.Delete(text2);  //kle
                string text6 = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/progController.ce");
                text2 = System.IO.Path.Combine(folderin, "Gen_Code/TOPGRID/progController.ck");
                u1680(text6, text2);
                u2001(folderin, "Gen_Code/TOPGRID/progController.ck", "col5", column5type);
                u2001(folderin, "Gen_Code/TOPGRID/progController.ck", "col6", column6type);
                u2001(folderin, "Gen_Code/TOPGRID/progController.ck", "col7", column7type);
                u2001(folderin, "Gen_Code/TOPGRID/progController.ck", "col8", column8type);
                u2001(folderin, "Gen_Code/TOPGRID/progController.ck", "col9", column9type);
                u2001(folderin, "Gen_Code/TOPGRID/progController.ck", "col10", column10type);
                u2001(folderin, "Gen_Code/TOPGRID/progController.ck", "col11", column11type);
                path = "Gen_Code/TOPGRID/" + progstr + "Controller.ck";
                text3 = System.IO.Path.Combine(folderin, path);
                text4 = System.IO.File.ReadAllText(text2);
                text4 = text4.Replace("~proj~", projstr);
                text4 = text4.Replace("~prog~", progstr);
                text4 = text4.Replace("~tablemodel~", tablestr);
                text4 = text4.Replace("~table~", tablestr);
                text4 = text4.Replace("~PK_ID~", strpkid);
                text4 = text4.Replace("~column1~", column1str);
                text4 = text4.Replace("~column2~", column2str);
                text4 = text4.Replace("~column3~", column3str);
                text4 = text4.Replace("~column4~", column4str);
                text4 = u00A0(text4, column5str, column5type, 5);
                text4 = u00A0(text4, column6str, column6type, 6);
                text4 = u00A0(text4, column7str, column7type, 7);
                text4 = u00A0(text4, column8str, column8type, 8);
                text4 = u00A0(text4, column9str, column9type, 9);
                text4 = u00A0(text4, column10str, column10type, 10);
                text4 = u00A0(text4, column11str, column11type, 11);
                System.IO.File.WriteAllText(text3, text4);
                path2 = folderin + "Controllers/" + progstr + "UI";
                if (!Directory.Exists(path2))
                {
                    Directory.CreateDirectory(path2);
                }
                path3 = string.Concat(new string[]
                {
            "Controllers/",
            progstr,
            "UI/",
            progstr,
            "Controller.cs"
                });
                text5 = System.IO.Path.Combine(folderin, path3);
                System.IO.File.Copy(text3, text5, true);
                System.IO.File.Delete(text3);
                System.IO.File.Delete(text2);  //kle

                path3 = "Shared/NavMenu.razor";
                text5 = System.IO.Path.Combine(folderin, path3);
                text5 = text5.Replace("Server", "Client");
                string text7 = string.Concat(new string[]
                {
            "<div class='nav-item px-3'><NavLink class='nav-link' href='",
            progstr.ToLower(),
            "grid'><span class='oi oi-person' aria-hidden='true'></span>",
            progstr,
            "</NavLink></div>"
                });
                u00A0(folderin, text5, "ADDLINKHERE", text7);
                result = true;
            }
            catch (Exception ex)
            {
                string message = ex.Message;
                result = false;
            }
            return result;
        }


        public static string DelALLProgs(string progstr, string modelstr, string folderin)
        {
            string result;
            try
            {
                //string str = folderin.Replace("KalWasm\\Server\\", "KalMauWasm\\");
                string text = folderin + "Pages/" + progstr + "UI";

                /*
                text = text.Replace("Server", "Client");
                if (Directory.Exists(text))
                {
                    Directory.Delete(text, true);
                }
                text = folderin + "Shared/" + progstr + "UI";
                text = text.Replace("Server", "Client");
                if (Directory.Exists(text))
                {
                    Directory.Delete(text, true);
                }
                text = folderin + "Controllers/" + progstr + "UI";
                if (Directory.Exists(text))
                {
                    Directory.Delete(text, true);
                }


                text = folderin + "Models/" + progstr + "UI";
                if (Directory.Exists(text))
                {
                    Directory.Delete(text, true);
                }

                */

                text = folderin + "Components/Pages/" + progstr + "UI";
                if (Directory.Exists(text))
                {
                    Directory.Delete(text, true);
                }


                string path = "Components/Layout/NavMenu.razor";
                string text2 = System.IO.Path.Combine(folderin, path);
                //text2 = text2.Replace("Server", "Client");
                string text3 = string.Concat(new string[]
                {
            "<div class='nav-item px-3'><NavLink class='nav-link' href='",
            progstr.ToLower(),
            "grid'><span class='bi bi-list-nested-nav-menu' aria-hidden='true'></span>",
            progstr,
            "</NavLink></div>"
                });
                u2000(folderin, text2, text3, "ADDLINKHERE");



                /*
                 
                text = folderin + progstr + "UI";
                text = text.Replace("Server", "Shared");
                if (Directory.Exists(text))
                {
                    Directory.Delete(text, true);
                }


                string path = "Components/Layout/NavMenu.razor";
                string text2 = System.IO.Path.Combine(folderin, path);
                //text2 = text2.Replace("Server", "Client");
                string text3 = string.Concat(new string[]
                {
            "<div class='nav-item px-3'><NavLink class='nav-link' href='",
            progstr.ToLower(),
            "grid'><span class='oi oi-person' aria-hidden='true'></span>",
            progstr,
            "</NavLink></div>"
                });
                u2000(folderin, text2, text3, "ADDLINKHERE");


                text = str + "Shared/" + progstr + "UI";
                if (Directory.Exists(text))
                {
                    Directory.Delete(text, true);
                }
                text = str + "Pages/" + progstr + "UI";
                if (Directory.Exists(text))
                {
                    Directory.Delete(text, true);
                }
                text = str + "Data/" + progstr + "UI";
                if (Directory.Exists(text))
                {
                    Directory.Delete(text, true);
                }


                string text4 = str + "Shared/NavMenu.razor";
                string text5 = string.Concat(new string[]
                {
            "<div class='nav-item px-3'><NavLink class='nav-link' href='",
            progstr.ToLower(),
            "grid'><span class='oi oi-person' aria-hidden='true'></span>",
            progstr,
            "</NavLink></div>"
                });
                u2000(folderin, text4, text5, "ADDLINKHERE");

                */


                result = "OK";
            }
            catch (Exception ex)
            {
                result = "Error is:- " + ex.Message;
            }
            return result;
        }



        private static bool u1680(string A_0, string A_1, string A_2, string A_3)
        {
            bool result;
            try
            {
                string path = System.IO.Path.Combine(A_0, A_1);
                string text = "";
                StreamReader streamReader = System.IO.File.OpenText(path);
                string text2;
                while ((text2 = streamReader.ReadLine()) != null)
                {
                    if (text2.Contains(A_2))
                    {
                        text = text + A_3 + Environment.NewLine;
                    }
                    text = text + text2 + Environment.NewLine;
                }
                streamReader.Close();
                System.IO.File.WriteAllText(path, text);
                result = true;
            }
            catch (Exception)

            {
                result = false;
            }
            return result;
        }


        private static bool u00A0(string A_0, string A_1, string A_2)
        {
            bool result;
            try
            {
                string path = System.IO.Path.Combine(A_0, A_1);
                string value = "~datetype" + A_2 + "~";
                string text = "";
                StreamReader streamReader = System.IO.File.OpenText(path);
                string text2;
                while ((text2 = streamReader.ReadLine()) != null)
                {
                    if (!text2.Contains(value))
                    {
                        text = text + text2 + Environment.NewLine;
                    }
                }
                streamReader.Close();
                System.IO.File.WriteAllText(path, text);
                string value2 = "~chartype" + A_2 + "~";
                string text3 = "";
                StreamReader streamReader2 = System.IO.File.OpenText(path);
                string text4;
                while ((text4 = streamReader2.ReadLine()) != null)
                {
                    if (!text4.Contains(value2))
                    {
                        text3 = text3 + text4 + Environment.NewLine;
                    }
                }
                streamReader2.Close();
                System.IO.File.WriteAllText(path, text3);
                string value3 = "~inttype" + A_2 + "~";
                string text5 = "";
                StreamReader streamReader3 = System.IO.File.OpenText(path);
                string text6;
                while ((text6 = streamReader3.ReadLine()) != null)
                {
                    if (!text6.Contains(value3))
                    {
                        text5 = text5 + text6 + Environment.NewLine;
                    }
                }
                streamReader3.Close();
                System.IO.File.WriteAllText(path, text5);
                string value4 = "~dectype" + A_2 + "~";
                string text7 = "";
                StreamReader streamReader4 = System.IO.File.OpenText(path);
                string text8;
                while ((text8 = streamReader4.ReadLine()) != null)
                {
                    if (!text8.Contains(value4))
                    {
                        text7 = text7 + text8 + Environment.NewLine;
                    }
                }
                streamReader4.Close();
                System.IO.File.WriteAllText(path, text7);
                result = true;
            }
            catch (Exception)

            {
                result = false;
            }
            return result;
        }



        private static bool u00A0(string A_0, string A_1, string A_2, string A_3)
        {
            u1680(A_0, A_1, A_2, A_3);
            return true;
        }


        private static string u00A0(string A_0, string A_1, string A_2, int A_3)
        {
            string result = "";
            string oldValue = "~column" + A_3.ToString() + "~";
            string newValue = "column" + A_3.ToString() + "BLANK";
            string oldValue2 = "Model.column" + A_3.ToString() + "BLANK";

            //next is for ValidationMessage of columns not found and remove in the Dialog page
            string oldValueVal = "<ValidationMessage For=\"@(() => ";
            oldValueVal = oldValueVal + "column" + A_3.ToString() + "BLANK";
            oldValueVal = oldValueVal + ")\"";

            string oldValue3 = "original." + "column" + A_3.ToString() + "BLANK";
            string newValue3 = "//original." + "column" + A_3.ToString() + "BLANK";



            string oldValue4 = "row." + "column" + A_3.ToString() + "BLANK";
            string newValue4 = "//row." + "column" + A_3.ToString() + "BLANK";

            string oldValue5 = "column" + A_3.ToString() + "BLANK" + " = p.";
            string newValue5 = "//column" + A_3.ToString() + "BLANK" + " = p.";

            string oldValue6 = "column" + A_3.ToString() + "BLANK" + " = //row." + "column" + A_3.ToString() + "BLANK";
            string newValue6 = "//column" + A_3.ToString() + "BLANK" + " = //row." + "column" + A_3.ToString() + "BLANK";
           

            string a = A_2.ToUpper();
            try
            {
                if (A_1 == "")
                {
                    A_0 = A_0.Replace(oldValue, newValue);
                    A_0 = A_0.Replace(oldValue2, newValue);
                    A_0 = A_0.Replace(oldValueVal, "<div ");

                    A_0 = A_0.Replace(oldValue3, newValue3);
                    A_0 = A_0.Replace(oldValue4, newValue4);
                    A_0 = A_0.Replace(oldValue5, newValue5);
                    A_0 = A_0.Replace(oldValue6, newValue6);
                }
                else
                {
                    A_0 = A_0.Replace(oldValue, A_1);
                }
                if (A_2.ToUpper() == "CHAR" || a == "VARCHAR" || a == "TEXT" || a == "BLOB")
                {
                    A_0 = A_0.Replace("~chartypecol" + A_3.ToString() + "~", "");
                }
                if (a == "INTEGER")
                {
                    A_0 = A_0.Replace("~inttypecol" + A_3.ToString() + "~", "");
                }
                if (a == "DECIMAL" || a == "MONEY" || a == "REAL")
                {
                    A_0 = A_0.Replace("~dectypecol" + A_3.ToString() + "~", "");
                }
                if (a == "DATE" || a == "DATETIME")
                {
                    A_0 = A_0.Replace("~datetypecol" + A_3.ToString() + "~", "");
                }
                if (a == "FINISH")
                {
                    A_0 = A_0.Replace("~dropdowntypecol" + A_3.ToString() + "~", "");
                    A_0 = A_0.Replace("~autodropdowntypecol" + A_3.ToString() + "~", "");
                }
                result = A_0;
            }
            catch
            {
                result = A_0;
            }
            return result;
        }




        private static void u1680(string A_0, string A_1)
        {
            string password = "MAKV2SPBNI99212";
            using (Aes aes = Aes.Create())
            {
                Rfc2898DeriveBytes rfc2898DeriveBytes = new Rfc2898DeriveBytes(password, new byte[]
                {
            73,
            118,
            97,
            110,
            32,
            77,
            101,
            100,
            118,
            101,
            100,
            101,
            118
                });
                aes.Key = rfc2898DeriveBytes.GetBytes(32);
                aes.IV = rfc2898DeriveBytes.GetBytes(16);
                using (FileStream fileStream = new FileStream(A_0, FileMode.Open))
                {
                    using (CryptoStream cryptoStream = new CryptoStream(fileStream, aes.CreateDecryptor(), CryptoStreamMode.Read))
                    {
                        using (FileStream fileStream2 = new FileStream(A_1, FileMode.Create))
                        {
                            int num;
                            while ((num = cryptoStream.ReadByte()) != -1)
                            {
                                fileStream2.WriteByte((byte)num);
                            }
                        }
                    }
                }
            }
        }



        private static bool u2001(string A_0, string A_1, string A_2)
        {
            bool result;
            try
            {
                string path = System.IO.Path.Combine(A_0, A_1);
                string value = "~chartype" + A_2 + "~";
                string text = "";
                StreamReader streamReader = System.IO.File.OpenText(path);
                string text2;
                while ((text2 = streamReader.ReadLine()) != null)
                {
                    if (!text2.Contains(value))
                    {
                        text = text + text2 + Environment.NewLine;
                    }
                }
                streamReader.Close();
                System.IO.File.WriteAllText(path, text);
                string value2 = "~inttype" + A_2 + "~";
                string text3 = "";
                StreamReader streamReader2 = System.IO.File.OpenText(path);
                string text4;
                while ((text4 = streamReader2.ReadLine()) != null)
                {
                    if (!text4.Contains(value2))
                    {
                        text3 = text3 + text4 + Environment.NewLine;
                    }
                }
                streamReader2.Close();
                System.IO.File.WriteAllText(path, text3);
                string value3 = "~dectype" + A_2 + "~";
                string text5 = "";
                StreamReader streamReader3 = System.IO.File.OpenText(path);
                string text6;
                while ((text6 = streamReader3.ReadLine()) != null)
                {
                    if (!text6.Contains(value3))
                    {
                        text5 = text5 + text6 + Environment.NewLine;
                    }
                }
                streamReader3.Close();
                System.IO.File.WriteAllText(path, text5);
                result = true;
            }
            catch (Exception)

            {
                result = false;
            }
            return result;
        }


        private static bool u2001(string A_0, string A_1, string A_2, string A_3)
        {
            bool result;
            try
            {
                if (A_3 == "")
                {
                    u00A0(A_0, A_1, A_2);
                }
                if (A_3.ToUpper() == "VARCHAR")
                {
                    u2002(A_0, A_1, A_2);
                }
                if (A_3.ToUpper() == "CHAR")
                {
                    u2002(A_0, A_1, A_2);
                }
                if (A_3.ToUpper() == "TEXT")
                {
                    u2002(A_0, A_1, A_2);
                }
                if (A_3.ToUpper() == "BLOB")
                {
                    u2002(A_0, A_1, A_2);
                }
                if (A_3.ToUpper() == "DATE" || A_3.ToUpper() == "DATETIME")
                {
                    u2001(A_0, A_1, A_2);
                }
                if (A_3.ToUpper() == "REAL")
                {
                    u2004(A_0, A_1, A_2);
                }
                if (A_3.ToUpper() == "INTEGER")
                {
                    u2003(A_0, A_1, A_2);
                }
                if (A_3.ToUpper() == "DECIMAL")
                {
                    u2004(A_0, A_1, A_2);
                }
                if (A_3.ToUpper() == "MONEY")
                {
                    u2004(A_0, A_1, A_2);
                }
                result = true;
            }
            catch (Exception ex)
            {
                string message = ex.Message;
                result = false;
            }
            return result;
        }



        private static bool u2002(string A_0, string A_1, string A_2)
        {
            bool result;
            try
            {
                string path = System.IO.Path.Combine(A_0, A_1);
                string value = "~datetype" + A_2 + "~";
                string text = "";
                StreamReader streamReader = System.IO.File.OpenText(path);
                string text2;
                while ((text2 = streamReader.ReadLine()) != null)
                {
                    if (!text2.Contains(value))
                    {
                        text = text + text2 + Environment.NewLine;
                    }
                }
                streamReader.Close();
                System.IO.File.WriteAllText(path, text);
                string value2 = "~inttype" + A_2 + "~";
                string text3 = "";
                StreamReader streamReader2 = System.IO.File.OpenText(path);
                string text4;
                while ((text4 = streamReader2.ReadLine()) != null)
                {
                    if (!text4.Contains(value2))
                    {
                        text3 = text3 + text4 + Environment.NewLine;
                    }
                }
                streamReader2.Close();
                System.IO.File.WriteAllText(path, text3);
                string value3 = "~dectype" + A_2 + "~";
                string text5 = "";
                StreamReader streamReader3 = System.IO.File.OpenText(path);
                string text6;
                while ((text6 = streamReader3.ReadLine()) != null)
                {
                    if (!text6.Contains(value3))
                    {
                        text5 = text5 + text6 + Environment.NewLine;
                    }
                }
                streamReader3.Close();
                System.IO.File.WriteAllText(path, text5);
                result = true;
            }
            catch (Exception)

            {
                result = false;
            }
            return result;
        }



        private static bool u1680(string A_0, string A_1, string A_2)
        {
            bool result;
            try
            {
                string path = System.IO.Path.Combine(A_0, A_1);
                string value = "~dropdowntype" + A_2 + "~";
                string text = "";
                StreamReader streamReader = System.IO.File.OpenText(path);
                string text2;
                while ((text2 = streamReader.ReadLine()) != null)
                {
                    if (!text2.Contains(value))
                    {
                        text = text + text2 + Environment.NewLine;
                    }
                }
                streamReader.Close();
                System.IO.File.WriteAllText(path, text);
                result = true;
            }
            catch (Exception)

            {
                result = false;
            }
            return result;
        }



        private static bool u2002(string A_0, string A_1, string A_2, string A_3)
        {
            bool result;
            try
            {
                if (A_3 == "")
                {
                    u1680(A_0, A_1, A_2);
                }
                if (A_3.ToUpper() == "START")
                {
                    u1680(A_0, A_1, A_2);
                }
                result = true;
            }
            catch (Exception ex)
            {
                string message = ex.Message;
                result = false;
            }
            return result;
        }


        private static bool u2003(string A_0, string A_1, string A_2)
        {
            bool result;
            try
            {
                string path = System.IO.Path.Combine(A_0, A_1);
                string value = "~chartype" + A_2 + "~";
                string text = "";
                StreamReader streamReader = System.IO.File.OpenText(path);
                string text2;
                while ((text2 = streamReader.ReadLine()) != null)
                {
                    if (!text2.Contains(value))
                    {
                        text = text + text2 + Environment.NewLine;
                    }
                }
                streamReader.Close();
                System.IO.File.WriteAllText(path, text);
                string value2 = "~datetype" + A_2 + "~";
                string text3 = "";
                StreamReader streamReader2 = System.IO.File.OpenText(path);
                string text4;
                while ((text4 = streamReader2.ReadLine()) != null)
                {
                    if (!text4.Contains(value2))
                    {
                        text3 = text3 + text4 + Environment.NewLine;
                    }
                }
                streamReader2.Close();
                System.IO.File.WriteAllText(path, text3);
                string value3 = "~dectype" + A_2 + "~";
                string text5 = "";
                StreamReader streamReader3 = System.IO.File.OpenText(path);
                string text6;
                while ((text6 = streamReader3.ReadLine()) != null)
                {
                    if (!text6.Contains(value3))
                    {
                        text5 = text5 + text6 + Environment.NewLine;
                    }
                }
                streamReader3.Close();
                System.IO.File.WriteAllText(path, text5);
                result = true;
            }
            catch (Exception)

            {
                result = false;
            }
            return result;
        }

        private static bool u2003(string A_0, string A_1, string A_2, string A_3)
        {
            bool result;
            try
            {
                if (A_3 == "")
                {
                    u2000(A_0, A_1, A_2);
                }
                if (A_3.ToUpper() == "START")
                {
                    u2000(A_0, A_1, A_2);
                }
                result = true;
            }
            catch (Exception ex)
            {
                string message = ex.Message;
                result = false;
            }
            return result;
        }


        private static bool u2004(string A_0, string A_1, string A_2)
        {
            bool result;
            try
            {
                string path = System.IO.Path.Combine(A_0, A_1);
                string value = "~chartype" + A_2 + "~";
                string text = "";
                StreamReader streamReader = System.IO.File.OpenText(path);
                string text2;
                while ((text2 = streamReader.ReadLine()) != null)
                {
                    if (!text2.Contains(value))
                    {
                        text = text + text2 + Environment.NewLine;
                    }
                }
                streamReader.Close();
                System.IO.File.WriteAllText(path, text);
                string value2 = "~datetype" + A_2 + "~";
                string text3 = "";
                StreamReader streamReader2 = System.IO.File.OpenText(path);
                string text4;
                while ((text4 = streamReader2.ReadLine()) != null)
                {
                    if (!text4.Contains(value2))
                    {
                        text3 = text3 + text4 + Environment.NewLine;
                    }
                }
                streamReader2.Close();
                System.IO.File.WriteAllText(path, text3);
                string value3 = "~inttype" + A_2 + "~";
                string text5 = "";
                StreamReader streamReader3 = System.IO.File.OpenText(path);
                string text6;
                while ((text6 = streamReader3.ReadLine()) != null)
                {
                    if (!text6.Contains(value3))
                    {
                        text5 = text5 + text6 + Environment.NewLine;
                    }
                }
                streamReader3.Close();
                System.IO.File.WriteAllText(path, text5);
                result = true;
            }
            catch (Exception)

            {
                result = false;
            }
            return result;
        }


        private static bool u2000(string A_0, string A_1, string A_2)
        {
            bool result;
            try
            {
                string path = System.IO.Path.Combine(A_0, A_1);
                string value = "~autodropdowntype" + A_2 + "~";
                string text = "";
                StreamReader streamReader = System.IO.File.OpenText(path);
                string text2;
                while ((text2 = streamReader.ReadLine()) != null)
                {
                    if (!text2.Contains(value))
                    {
                        text = text + text2 + Environment.NewLine;
                    }
                }
                streamReader.Close();
                System.IO.File.WriteAllText(path, text);
                result = true;
            }
            catch (Exception)

            {
                result = false;
            }
            return result;
        }


        private static bool u2000(string A_0, string A_1, string A_2, string A_3)
        {
            bool result;
            try
            {
                string path = System.IO.Path.Combine(A_0, A_1);
                string text = "";
                StreamReader streamReader = System.IO.File.OpenText(path);
                string text2;
                while ((text2 = streamReader.ReadLine()) != null)
                {
                    if (!text2.Contains(A_2))
                    {
                        text = text + text2 + Environment.NewLine;
                    }
                }
                streamReader.Close();
                System.IO.File.WriteAllText(path, text);
                result = true;
            }
            catch (Exception)

            {
                result = false;
            }
            return result;
        }






    }
}
