using BlazKal.Models;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace BlazKal.Data
{
   
    public class ApplicationDbContext
        : IdentityDbContext<ApplicationUser>   // ← IMPORTANT
    {
        public ApplicationDbContext(
            DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }


        //ADDMODELHERE

    }


}
