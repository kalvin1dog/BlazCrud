namespace BlazKal.Components.Account
{
    public class PasskeyInputModel
    {
        public string? CredentialJson { get; set; }
        public string? Error { get; set; }
    }
}
