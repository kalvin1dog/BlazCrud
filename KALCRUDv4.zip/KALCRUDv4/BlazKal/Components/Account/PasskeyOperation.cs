namespace BlazKal.Components.Account
{
    public enum PasskeyOperation
    {
        Create = 0,
        Request = 1,
    }
}
