﻿namespace BlazKal.Shared
{
    public class TableGen
    {
        public long id { get; set; }

        public string Table_Name { get; set; }

        public string Field_Name { get; set; }

        public string Data_Type { get; set; }

        public int Length_Size { get; set; }

    }
    public class TableName
    {
        public string Table_Name { get; set; }
    }


}
