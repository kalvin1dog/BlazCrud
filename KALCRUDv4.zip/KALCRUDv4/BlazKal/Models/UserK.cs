using System.ComponentModel.DataAnnotations;

namespace BlazKal.Models
{
  
    public class UserK
    {
        [Key]
        public int UserK_ID { get; set; }   //use int for SqLite DB , use long if SQLServer


        //Required validation is optional
        [Required]
        //[Required, MaxLength(100)]
         public string? FirstName { get; set; } = string.Empty;

        //Required validation is optional
        [Required]
        //[Required, MaxLength(100)]
        public string? LastName { get; set; } = string.Empty;
        
        //Required validation is optional
        [Required]
        //[Required, MaxLength(100)]
        public string? UserType { get; set; } = string.Empty;
        
        //Required validation is optional
        [Required]
        //[Required, MaxLength(100)]
        public string? PaidType { get; set; } = string.Empty;


        //Required validation is optional
        //[Required]
        //[Required, MaxLength(100)]

        //Required validation is optional
        //[Required]
        //[Required, MaxLength(100)]

        //Required validation is optional
        //[Required]
        //[Required, MaxLength(100)]

        //Required validation is optional
        //[Required]
        //[Required, MaxLength(100)]

        //Required validation is optional
        //[Required]
        //[Required, MaxLength(100)]
        
        //Required validation is optional
        //[Required]
        //[Required, MaxLength(100)]
        
        //Required validation is optional
        //[Required]
        //[Required, MaxLength(100)]

      

    }

    
 public class UserKUtil
    {

        //These next are for columns do not exist
        public string column1BLANK { get; set; }
        public string column2BLANK { get; set; }
        public string column3BLANK { get; set; }
        public string column4BLANK { get; set; }
        public string column5BLANK { get; set; }
        public string column6BLANK { get; set; }
        public string column7BLANK { get; set; }
        public string column8BLANK { get; set; }
        public string column9BLANK { get; set; }
        public string column10BLANK { get; set; }
        public string column11BLANK { get; set; }

}


}

