﻿namespace BlazKal.Shared
{
    public class TableCol
    {
        public string Column_Name { get; set; }

        public string Column_Type { get; set; }
        public string Column_TypeR { get; set; }
    }

}
